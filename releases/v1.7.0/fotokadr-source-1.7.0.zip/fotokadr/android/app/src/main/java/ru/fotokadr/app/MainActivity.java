package ru.fotokadr.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

/** Native file access around the same local editor used on desktop. */
public final class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START = "https://" + HOST + "/assets/index.html";
    private static final int OPEN_PHOTO = 100, SAVE_PHOTO = 101;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private WebView editor;
    private FrameLayout rootView;
    private ValueCallback<Uri[]> photoCallback;
    private String pendingId;
    private byte[] pendingPhoto;

    @Override public void onCreate(Bundle state) {
        boolean dark = "dark".equals(getPreferences(MODE_PRIVATE).getString("theme", "light"));
        // The system splash is dark; choose the saved Activity theme before any view is created.
        setTheme(dark ? R.style.DarkTheme : R.style.AppTheme);
        super.onCreate(state);
        FrameLayout root = new FrameLayout(this);
        rootView = root;
        applyTheme(dark);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets.consumeSystemWindowInsets();
        });
        editor = new WebView(this);
        applyTheme(dark);
        root.addView(editor, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        WebSettings settings = editor.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // System picker grants only the chosen photo.
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setBlockNetworkLoads(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        editor.addJavascriptInterface(new SaveBridge(), "FotoKadrAndroid");
        editor.addJavascriptInterface(new ThemeBridge(), "FotoKadrTheme");
        editor.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // The editor never leaves its packaged main page.
                return !START.equals(request.getUrl().toString());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!"https".equals(uri.getScheme()) || !HOST.equals(uri.getHost()) || !"GET".equals(request.getMethod())) return missing();
                String path = uri.getPath();
                if (path == null || !path.startsWith("/assets/") || path.contains("..") || path.contains("\\")) return missing();
                String asset = path.substring("/assets/".length());
                try {
                    InputStream body = getAssets().open("web/" + asset);
                    Map<String, String> headers = new HashMap<>();
                    headers.put("X-Content-Type-Options", "nosniff");
                    headers.put("Content-Security-Policy", "default-src 'self' blob: data:; script-src 'self' blob: 'wasm-unsafe-eval'; worker-src 'self' blob:; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; connect-src 'self' blob:; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'");
                    return new WebResourceResponse(mime(asset), null, 200, "OK", headers, body);
                } catch (IOException error) { return missing(); }
            }
        });
        editor.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (photoCallback != null) photoCallback.onReceiveValue(null);
                photoCallback = callback;
                Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                picker.addCategory(Intent.CATEGORY_OPENABLE);
                picker.setType("image/*");
                picker.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { startActivityForResult(picker, OPEN_PHOTO); }
                catch (ActivityNotFoundException error) {
                    photoCallback.onReceiveValue(null); photoCallback = null;
                    Toast.makeText(MainActivity.this, "Не удалось открыть выбор фотографии.", Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });
        editor.loadUrl(START);
    }

    private void applyTheme(boolean dark) {
        int background = dark ? 0xff121212 : 0xffffffff;
        if (rootView != null) rootView.setBackgroundColor(background);
        if (editor != null) editor.setBackgroundColor(background);
        getWindow().setStatusBarColor(background);
        getWindow().setNavigationBarColor(background);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0 :
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }

    private final class ThemeBridge {
        @JavascriptInterface public void setTheme(String theme) {
            if (!"dark".equals(theme) && !"light".equals(theme)) return;
            getPreferences(MODE_PRIVATE).edit().putString("theme", theme).apply();
            runOnUiThread(() -> applyTheme("dark".equals(theme)));
        }
    }

    private static WebResourceResponse missing() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null, new ByteArrayInputStream(new byte[0]));
    }
    private static String mime(String path) {
        if (path.endsWith(".html")) return "text/html";
        if (path.endsWith(".js") || path.endsWith(".mjs")) return "application/javascript";
        if (path.endsWith(".css")) return "text/css";
        if (path.endsWith(".svg")) return "image/svg+xml";
        if (path.endsWith(".png")) return "image/png";
        if (path.endsWith(".json") || path.endsWith(".webmanifest")) return "application/json";
        if (path.endsWith(".wasm")) return "application/wasm";
        return "application/octet-stream";
    }

    public final class SaveBridge {
        @JavascriptInterface public void saveJpeg(String id, String encoded, String fileName) {
            if (id == null || !id.matches("save-[0-9]{1,16}")) return;
            if (encoded == null || encoded.length() > 24 * 1024 * 1024) {
                report(id, "error", "Фото слишком большое для сохранения."); return;
            }
            // This method runs on WebView's bridge thread, away from the UI.
            final byte[] bytes;
            try { bytes = Base64.decode(encoded, Base64.NO_WRAP); }
            catch (IllegalArgumentException error) { report(id, "error", "Не удалось прочитать готовое фото."); return; }
            if (bytes.length < 4 || bytes.length > 16 * 1024 * 1024 || (bytes[0] & 255) != 255 || (bytes[1] & 255) != 216 || (bytes[bytes.length - 2] & 255) != 255 || (bytes[bytes.length - 1] & 255) != 217) {
                report(id, "error", "Некорректный файл JPG."); return;
            }
            String safeName = fileName == null ? "fotokadr.jpg" : fileName.replaceAll("[^a-zA-Z0-9а-яА-ЯёЁ._-]", "_");
            if (safeName.length() > 120) safeName = safeName.substring(0, 116) + ".jpg";
            if (!safeName.endsWith(".jpg")) safeName += ".jpg";
            final String name = safeName;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                if (pendingId != null) { report(id, "error", "Завершите предыдущее сохранение."); return; }
                pendingId = id; pendingPhoto = bytes;
                Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                save.addCategory(Intent.CATEGORY_OPENABLE);
                save.setType("image/jpeg");
                save.putExtra(Intent.EXTRA_TITLE, name);
                try { startActivityForResult(save, SAVE_PHOTO); }
                catch (ActivityNotFoundException error) {
                    pendingId = null; pendingPhoto = null;
                    report(id, "error", "Не удалось открыть окно сохранения.");
                }
            });
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == OPEN_PHOTO && photoCallback != null) {
            Uri uri = result == RESULT_OK && data != null ? data.getData() : null;
            photoCallback.onReceiveValue(uri == null ? null : new Uri[]{uri});
            photoCallback = null;
        } else if (request == SAVE_PHOTO && pendingId != null) {
            final String id = pendingId;
            final byte[] bytes = pendingPhoto;
            pendingId = null; pendingPhoto = null;
            final Uri uri = result == RESULT_OK && data != null ? data.getData() : null;
            if (uri == null) { report(id, "cancelled", "Сохранение отменено."); return; }
            io.execute(() -> {
                try (OutputStream output = getContentResolver().openOutputStream(uri, "wt")) {
                    if (output == null) throw new IOException("No output stream");
                    output.write(bytes); output.flush();
                } catch (IOException | SecurityException error) { report(id, "error", "Не удалось записать фото. Выберите другую папку."); return; }
                report(id, "saved", "Фото сохранено.");
            });
        }
    }

    private void report(String id, String status, String message) {
        String detail = "{id:" + JSONObject.quote(id) + ",status:" + JSONObject.quote(status) + ",message:" + JSONObject.quote(message) + "}";
        runOnUiThread(() -> {
            if (editor != null && !isDestroyed()) editor.evaluateJavascript("window.dispatchEvent(new CustomEvent('fotokadr-save-result',{detail:" + detail + "}));", null);
        });
    }

    @Override protected void onDestroy() {
        if (photoCallback != null) { photoCallback.onReceiveValue(null); photoCallback = null; }
        pendingPhoto = null;
        if (editor != null) { editor.removeJavascriptInterface("FotoKadrAndroid"); editor.destroy(); editor = null; }
        io.shutdown();
        super.onDestroy();
    }
}
