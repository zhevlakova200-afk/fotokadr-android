import assert from 'node:assert/strict';
import test from 'node:test';
import { readFile } from 'node:fs/promises';

// Import as an ES module independently of the parent project's package type.
const source = await readFile(new URL('../dist/photo-engine.js', import.meta.url), 'utf8');
const { dimensionsForFormat, cropRect, jpegWithDpi, drawPhoto } = await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
const near = (actual, expected) => assert.ok(Math.abs(actual - expected) < 1e-8, `${actual} ≠ ${expected}`);

test('requested print dimensions at 300 DPI', () => {
  assert.deepEqual(dimensionsForFormat(4, 6), { width: 472, height: 709 });
  assert.deepEqual(dimensionsForFormat(9, 12), { width: 1063, height: 1417 });
  assert.deepEqual(dimensionsForFormat(4, 3), { width: 472, height: 354 });
  assert.deepEqual(dimensionsForFormat(6, 4), { width: 709, height: 472 });
  assert.throws(() => dimensionsForFormat(0, 6), RangeError);
  assert.throws(() => dimensionsForFormat(4, Infinity), RangeError);
});

test('landscape image fills portrait crop without stretching', () => {
  const crop = cropRect(1800, 1200, 4 / 6);
  assert.deepEqual(crop, { x: 500, y: 0, width: 800, height: 1200 });
  assert.equal(cropRect(1800, 1200, 4 / 6, 1, -1).x, 0);
  assert.equal(cropRect(1800, 1200, 4 / 6, 1, 1).x, 1000);
});

test('all crop formats and pan extremes remain in source bounds', () => {
  for (const [iw, ih] of [[4000, 3000], [1200, 2400], [300, 300]]) {
    for (const ratio of [4 / 6, 9 / 12, 4 / 3, 6 / 4]) {
      for (const zoom of [0.5, 1, 1.5, 4]) {
        for (const panX of [-3, -1, 0, 1, 3]) {
          for (const panY of [-3, -1, 0, 1, 3]) {
            const rect = cropRect(iw, ih, ratio, zoom, panX, panY);
            assert.ok(rect.x >= 0 && rect.y >= 0);
            assert.ok(rect.x + rect.width <= iw + 1e-8);
            assert.ok(rect.y + rect.height <= ih + 1e-8);
            near(rect.width / rect.height, ratio);
          }
        }
      }
    }
  }
});

test('zoom reduces the source rectangle proportionally', () => {
  const base = cropRect(2400, 3200, 0.75);
  const zoomed = cropRect(2400, 3200, 0.75, 2);
  near(zoomed.width, base.width / 2);
  near(zoomed.height, base.height / 2);
  assert.deepEqual(zoomed, { x: 600, y: 800, width: 1200, height: 1600 });
  assert.throws(() => cropRect(0, 100, 1), RangeError);
  assert.throws(() => cropRect(100, 100, 1, NaN), RangeError);
});

test('JFIF metadata records 300 DPI while preserving encoded image bytes', () => {
  const original = new Uint8Array([0xff, 0xd8, 0xff, 0xe0, 0, 16, 74, 70, 73, 70, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0xff, 0xda, 12, 34, 0xff, 0xd9]);
  const patched = jpegWithDpi(original);
  assert.equal(patched[13], 1);
  assert.equal((patched[14] << 8) | patched[15], 300);
  assert.equal((patched[16] << 8) | patched[17], 300);
  assert.deepEqual(patched.slice(20), original.slice(20));
  assert.equal(original[13], 0, 'input bytes are not mutated');
});

test('JPEG without JFIF receives one without modifying original segments', () => {
  const original = new Uint8Array([0xff, 0xd8, 0xff, 0xda, 12, 34, 0xff, 0xd9]);
  const patched = jpegWithDpi(original);
  assert.equal(patched.length, original.length + 18);
  assert.deepEqual(patched.slice(20), original.slice(2));
  assert.equal((patched[14] << 8) | patched[15], 300);
  assert.throws(() => jpegWithDpi(new Uint8Array([1, 2])), TypeError);
});

test('preview and export render the same crop; grayscale and corner are applied', () => {
  const calls = [];
  const pixels = new Uint8ClampedArray([200, 100, 20, 255]);
  const context = {
    fillRect() {}, drawImage(...args) { calls.push(args); },
    getImageData() { return { data: pixels }; }, putImageData() {},
    beginPath() {}, moveTo() {}, lineTo() {}, closePath() {}, fill() {},
    ellipse(...args) { calls.push(['ellipse', ...args]); },
  };
  const canvas = { getContext: () => context };
  const image = { naturalWidth: 2400, naturalHeight: 3200 };
  const options = { widthCm: 4, heightCm: 6, zoom: 1.7, panX: 0.4, panY: -0.3, grayscale: true, corner: true, cornerSize: .25 };
  const preview = drawPhoto(canvas, image, { ...options, previewWidth: 400 });
  const output = drawPhoto(canvas, image, options);
  assert.deepEqual(preview.sourceRect, output.sourceRect);
  assert.deepEqual([preview.width, preview.height], [400, 600]);
  assert.deepEqual([output.width, output.height], [472, 709]);
  assert.equal(pixels[0], pixels[1]);
  assert.equal(pixels[1], pixels[2]);
  const cornerCalls = calls.filter(call => call[0] === 'ellipse');
  assert.equal(cornerCalls[0][1], 400);
  assert.equal(cornerCalls[0][2], 600);
  assert.equal(cornerCalls[1][1], 472);
  assert.equal(cornerCalls[1][2], 709);
});

test('clothing stays attached to source coordinates and is flattened before grayscale and corner in preview and export', () => {
  const photo = { naturalWidth: 2400, naturalHeight: 3600 };
  const garment = { naturalWidth: 1000, naturalHeight: 800 };
  const results = [];
  for (const previewWidth of [400, undefined]) {
    const calls = [];
    const ctx = {
      fillRect() {}, save() {}, restore() {},
      scale(...v) { calls.push(['scale', ...v]); }, translate(...v) { calls.push(['translate', ...v]); }, rotate(...v) { calls.push(['rotate', ...v]); },
      drawImage(image, ...v) { calls.push([image === garment ? 'garment' : 'photo', ...v]); },
      getImageData() { calls.push(['grayscale']); return { data: new Uint8ClampedArray([100, 200, 250, 255]) }; }, putImageData() {},
      beginPath() {}, moveTo() {}, lineTo() {}, closePath() {}, ellipse() {}, fill() { calls.push(['corner']); },
    };
    const output = drawPhoto({ getContext: () => ctx }, photo, { previewWidth, zoom: 1.5, panX: .2,
      clothing: { image: garment, x: .52, y: .75, width: .8, angle: 10 }, grayscale: true, corner: true });
    const translate = calls.find(c => c[0] === 'translate');
    near(translate[1], 2400 * .52 - output.sourceRect.x);
    near(translate[2], 3600 * .75 - output.sourceRect.y);
    const scale = calls.find(c => c[0] === 'scale');
    near(scale[1], output.width / output.sourceRect.width);
    near(scale[2], output.height / output.sourceRect.height);
    assert.ok(calls.findIndex(c => c[0] === 'garment') < calls.findIndex(c => c[0] === 'grayscale'));
    assert.ok(calls.findIndex(c => c[0] === 'grayscale') < calls.findIndex(c => c[0] === 'corner'));
    results.push(calls.filter(c => ['garment', 'translate', 'rotate'].includes(c[0])));
  }
  assert.deepEqual(results[0], results[1]);
});

test('replacement changes actual layer order while protecting head and neck in both modes',()=>{
  const photo={width:800,height:1200},background={width:800,height:1200},preserved={width:800,height:1200},protectedLayer={width:800,height:1200},garment={width:1000,height:1400};
  function render(mode,x=.5,angle=6,previewWidth=400){
    const images=[],transforms=[];
    const ctx={fillRect(){},save(){},restore(){},scale(){},rotate(v){transforms.push(['rotate',v]);},translate(...v){transforms.push(['translate',...v]);},drawImage(image){images.push(image);}};
    const result=drawPhoto({getContext:()=>ctx},photo,{previewWidth,clothing:{background,preserved,protected:protectedLayer,image:garment,x,y:.7,width:.9,angle,layerMode:mode}});
    return {images,transforms,result};
  }
  for(const mode of ['front','behind','front','behind']) {
    const r=render(mode);
    assert.deepEqual(r.images,mode==='front'?[background,preserved,garment,protectedLayer]:[background,garment,preserved,protectedLayer]);
    assert.equal(r.transforms.filter(v=>v[0]==='translate').length,1,'person layers have no garment transform');
  }
  assert.notDeepEqual(render('front',.5).transforms,render('front',.7).transforms,'moving clothing affects only its matrix');
  assert.notDeepEqual(render('front',.5,6).transforms,render('front',.5,24).transforms,'rotation changes garment matrix');
  assert.deepEqual(render('behind',.5,6,400).transforms.filter(v=>v[0]!=='scale'),render('behind',.5,6,undefined).transforms.filter(v=>v[0]!=='scale'),'preview/export share source-space transforms');
});
