import assert from 'node:assert/strict';
import test from 'node:test';
import { createClothingMask, paintMask, applyMaskChanges, maskLayers } from '../dist/clothing-masks.js';

function portrait() {
  const width=120,height=160,pixels=new Uint8ClampedArray(width*height*4);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++) {
    const head=(x-60)**2/22**2+(y-49)**2/30**2<1;
    const neck=x>=51&&x<=69&&y>=70&&y<=106;
    const jacket=y>=98&&x>=24&&x<=96;
    const hand=y>=113&&x>=14&&x<=27;
    const colour=head||neck||hand?[173,124,91]:jacket?[36,58,41]:[255,255,255];
    pixels.set([...colour,255],(y*width+x)*4);
  }
  return {width,height,pixels,face:{x:38/120,y:22/160,width:44/120,height:54/160}};
}
const at=(mask,x,y)=>mask.classes[y*mask.width+x];

test('military jacket is removed independently while face and connected visible neck survive',()=>{
  const {pixels,width,height,face}=portrait(),original=pixels.slice();
  const mask=createClothingMask(pixels,width,height,face);
  for(let y=48;y<=100;y++)assert.equal(at(mask,60,y),2,`connected neck at y=${y}`);
  assert.equal(at(mask,60,120),0,'old jacket removed');
  assert.equal(at(mask,20,120),1,'visible hand preserved for behind mode');
  const layers=maskLayers(pixels,mask);
  assert.equal(layers.protected[(85*width+60)*4+3]>0,true);
  assert.equal(layers.protected[(120*width+60)*4+3],0);
  assert.equal(layers.preserved[(120*width+60)*4+3],0);
  assert.deepEqual(pixels,original,'segmentation never changes original portrait');
});

test('protect/remove brushes correct collar errors with exact undo and redo',()=>{
  const {pixels,width,height,face}=portrait(),mask=createClothingMask(pixels,width,height,face);
  const before=mask.classes.slice(),beforeAlpha=mask.alpha.slice();
  const remove=paintMask(mask,60,100,4,'remove');
  assert.equal(at(mask,60,100),0);
  const protect=paintMask(mask,60,120,4,'protect');
  assert.equal(at(mask,60,120),2);
  applyMaskChanges(mask,[...remove,...protect],true);
  assert.deepEqual(mask.classes,before);assert.deepEqual(mask.alpha,beforeAlpha);
  applyMaskChanges(mask,[...remove,...protect],false);
  assert.equal(at(mask,60,100),0);assert.equal(at(mask,60,120),2);
});
