import test from 'node:test';
import assert from 'node:assert/strict';
import { createTemplateStore } from '../dist/template-store.js';

// Control the IndexedDB transaction boundary. A request success is NOT a
// durable commit: the entire transaction may still fail (disk full, abort).
function database() {
  const transactions = [];
  const db = {
    objectStoreNames: { contains: () => true },
    transaction(name, mode) {
      assert.equal(name, 'templates');
      const request = {};
      const tx = { mode, request, objectStore: () => ({
        put(record) { tx.record = record; return request; },
        getAll() { return request; },
        delete(id) { tx.deleted = id; return request; },
      }), abort() { tx.onabort(); } };
      transactions.push(tx);
      return tx;
    },
    close() { this.closed = true; },
  };
  const factory = { open() { const request = { result: db }; queueMicrotask(() => request.onsuccess()); return request; } };
  return { store: createTemplateStore(factory), db, transactions,
    async latest() { for (let i = 0; i < 8; i++) await Promise.resolve(); return transactions.at(-1); } };
}

test('template import resolves only after a committed Blob transaction', async () => {
  const h = database();
  const record = { id: 'suit', name: 'Пиджак', blob: new Blob(['PNG pixels'], { type: 'image/png' }) };
  let finished = false;
  const save = h.store.put(record).then(() => { finished = true; });
  const tx = await h.latest();
  assert.equal(tx.mode, 'readwrite');
  assert.equal(tx.record.blob, record.blob);
  tx.request.result = record.id;
  tx.request.onsuccess();
  await Promise.resolve();
  assert.equal(finished, false);
  tx.oncomplete();
  await save;
  assert.equal(finished, true);
  await h.store.close();
  assert.equal(h.db.closed, true);
});

test('quota failure after request success rejects instead of claiming the template was saved', async () => {
  const h = database();
  const save = h.store.put({ id: 'suit' });
  const failed = assert.rejects(save, { name: 'QuotaExceededError' });
  const tx = await h.latest();
  tx.request.onsuccess();
  tx.error = Object.assign(new Error('full'), { name: 'QuotaExceededError' });
  tx.onabort();
  await failed;
});

test('listing and deletion use committed transactions; unavailable storage rejects clearly', async () => {
  const h = database();
  const pending = h.store.list();
  const read = await h.latest();
  assert.equal(read.mode, 'readonly');
  read.request.result = [{ id: 'shirt' }]; read.request.onsuccess(); read.oncomplete();
  assert.deepEqual(await pending, [{ id: 'shirt' }]);
  const removing = h.store.remove('shirt');
  const write = await h.latest();
  assert.equal(write.deleted, 'shirt'); write.request.onsuccess(); write.oncomplete(); await removing;
  await assert.rejects(createTemplateStore().list(), /Хранилище недоступно/);
});
