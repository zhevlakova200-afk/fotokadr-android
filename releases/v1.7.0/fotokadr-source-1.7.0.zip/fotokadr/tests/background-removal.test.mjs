import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { boundedImageSize, mattingInputSize, normalisePortraitRgb, matteHasPerson, decodeEmbeddedAsset } from '../dist/background-removal.js';

// Inference is substituted at the ONNX boundary, but the actual serialized
// worker, preprocessor, messages, cancellation and main-thread compositor run.
// This does not claim a real-model visual test.
function browserMock({ empty = false, failure = false, held = false } = {}) {
  const previous = { document: globalThis.document, Worker: globalThis.Worker, URL: globalThis.URL };
  const workers = [], canvases = [], calls = { downloads: [], tensors: [], configurations: [], runtime: null };
  const blobs = new Map(); let serial = 0;
  globalThis.URL = { createObjectURL(blob) { const url = `blob:worker-${++serial}`; blobs.set(url,blob); return url; }, revokeObjectURL(url) { blobs.delete(url); } };
  const embedded = {
    runtime: new TextEncoder().encode('offline runtime fixture'),
    module: new TextEncoder().encode('offline module fixture'),
    wasm: new Uint8Array([0,97,115,109,1,0,0,0]),
    model: new Uint8Array([1,2,3,4,5,6,7,8]),
  };
  globalThis.document = { getElementById(id) {
    const data=embedded[id.replace('offline-','')];
    return data ? {textContent:Buffer.from(data).toString('base64')} : null;
  }, createElement(kind) {
    assert.equal(kind,'canvas');
    const canvas = { width: 0, height: 0, draws: [], writes: [] };
    const context = {
      fillRect() {},
      drawImage(image) { canvas.draws.push(image); },
      getImageData(x,y,width,height) {
        const data = new Uint8ClampedArray(width*height*4);
        for(let i=0;i<data.length;i+=4) { data[i]=70; data[i+1]=90; data[i+2]=110; data[i+3]=255; }
        return { data, width, height };
      },
      putImageData(pixels,x,y) { canvas.writes.push({ pixels, x, y }); },
    };
    canvas.getContext = () => context; canvases.push(canvas); return canvas;
  } };
  globalThis.Worker = class {
    constructor(url) { this.source=blobs.get(url); workers.push(this); }
    terminate() { this.terminated=true; }
    postMessage(input) {
      this.input=input;
      if(held) return;
      this.task=this.execute(input);
    }
    async execute(input) {
      const worker=this;
      const self={
        postMessage(data) { if(!worker.terminated) worker.onmessage?.({data}); },
        close() {},
      };
      const runtime={
        env:{wasm:{}},
        Tensor:class { constructor(type,data,dims) { Object.assign(this,{type,data,dims}); calls.tensors.push(this); } dispose(){} },
        InferenceSession:{async create(model,options) {
          calls.configurations.push(options);
          return { inputNames:['input'],outputNames:['output'], async run(feeds) {
            assert.ok(feeds.input);
            const alpha=new Float32Array(64*96).fill(empty?0:1);
            return {output:{dims:[1,1,96,64],data:alpha,dispose(){}}};
          },async release(){} };
        }},
      };
      calls.runtime=runtime;
      const context=vm.createContext({self,Float32Array,Uint8ClampedArray,console,
        importScripts(url) { calls.script=url; calls.importedBlob=blobs.get(url); if(failure) throw new Error('runtime unavailable'); self.ort=runtime; },
        async fetch(url,options) { calls.downloads.push({url,options}); throw new Error('Network is disabled in the offline test'); },
      });
      vm.runInContext(await this.source.text(),context);
      await self.onmessage({data:input});
    }
  };
  return { workers,canvases,calls,blobs, restore() { globalThis.document=previous.document;globalThis.Worker=previous.Worker;globalThis.URL=previous.URL; } };
}

let serial=0;
const fresh=()=>import(`../dist/background-removal.js?test=${++serial}`);

test('mobile output bounds and portrait inference resolution preserve the intended scale',()=>{
  assert.deepEqual(boundedImageSize(1200,1800),{width:1200,height:1800});
  const large=boundedImageSize(8000,6000);
  assert.ok(large.width*large.height<=12000000 && large.width<=4096 && large.height<=4096);
  assert.deepEqual(mattingInputSize(2400,3600),{width:512,height:768});
  for(const [w,h] of [[100,100],[8000,1000],[1000,8000]]) {
    const shape=mattingInputSize(w,h); assert.equal(shape.width%32,0);assert.equal(shape.height%32,0);assert.ok(Math.max(shape.width,shape.height)<=1024);
  }
  assert.throws(()=>mattingInputSize(0,100));
});

test('RGB preprocessing uses unquantized channel-first [-1,1] values',()=>{
  const input=new Uint8ClampedArray([0,127,255,255,255,0,127,255]);
  const copy=new Uint8ClampedArray(input);
  const data=normalisePortraitRgb(input,2,1);
  assert.deepEqual([data[0],data[1],data[3],data[4]],[-1,1,-1,1]);
  assert.ok(Math.abs(data[2]-(127/127.5-1))<1e-7);
  assert.deepEqual(input,copy);
  assert.throws(()=>normalisePortraitRgb(input,3,1));
});

test('matte validation rejects blank and non-finite model outputs',()=>{
  assert.equal(matteHasPerson(new Float32Array(100)),false);
  assert.equal(matteHasPerson(new Float32Array([1,NaN])),false);
  assert.equal(matteHasPerson(new Float32Array(100).fill(.8)),true);
});

test('actual worker uses embedded model/runtime with network disabled and preserves original texture',async()=>{
  const mock=browserMock();
  try {
    const {removePortraitBackground}=await fresh();
    const original={naturalWidth:300,naturalHeight:450};
    const progress=[];
    const output=await removePortraitBackground(original,{onProgress:message=>progress.push(message)});
    assert.deepEqual([output.width,output.height],[300,450]);
    assert.deepEqual(original,{naturalWidth:300,naturalHeight:450});
    assert.equal(mock.workers.length,1);assert.equal(mock.workers[0].terminated,true);
    assert.match(mock.calls.script,/^blob:/);
    assert.equal(await mock.calls.importedBlob.text(),'offline runtime fixture');
    assert.equal(mock.calls.downloads.length,0,'never fetches a model from the internet');
    assert.match(mock.calls.runtime.env.wasm.wasmPaths.mjs,/^blob:/);
    assert.match(mock.calls.runtime.env.wasm.wasmPaths.wasm,/^blob:/);
    assert.equal(mock.calls.runtime.env.wasm.wasmBinary,undefined,'ORT must pass locateFile for blob module URLs');
    assert.deepEqual(Array.from(new Uint8Array(mock.workers[0].input.model)),[1,2,3,4,5,6,7,8]);
    assert.deepEqual(Array.from(mock.calls.tensors[0].dims),[1,3,768,512]);
    assert.equal(mock.calls.runtime.env.wasm.numThreads,1);
    assert.equal(mock.calls.runtime.env.wasm.proxy,false);
    assert.equal(output.draws[0],original,'renders original resolution, not the smaller inference image');
    assert.deepEqual(Array.from(output.writes[0].pixels.data.slice(0,4)),[70,90,110,255]);
    assert.ok(progress.some(message=>/волос/.test(message)));
    assert.ok(output.writes.every(band=>band.pixels.height<=128),'bounds full-resolution readback memory');
    assert.equal(mock.blobs.size,0,'releases runtime, module, WASM and worker blob URLs');
  } finally {mock.restore();}
});

test('cancel terminates inference immediately and ignores late worker messages',async()=>{
  const mock=browserMock({held:true});
  try {
    const {removePortraitBackground}=await fresh();
    const controller=new AbortController();
    const pending=removePortraitBackground({width:100,height:150},{signal:controller.signal});
    for(let tick=0;tick<8 && !mock.workers.length;tick++) await Promise.resolve();
    assert.equal(mock.workers.length,1);
    controller.abort();
    await assert.rejects(pending,{name:'AbortError'});
    assert.equal(mock.workers[0].terminated,true);
    mock.workers[0].onmessage({data:{type:'result',width:64,height:96,alpha:new Float32Array(64*96).fill(1).buffer}});
    assert.ok(mock.canvases.every(canvas=>canvas.width===1));
  } finally {mock.restore();}
});

test('already cancelled work allocates no worker',async()=>{
  const mock=browserMock();
  try {
    const {removePortraitBackground}=await fresh();
    const controller=new AbortController();controller.abort();
    await assert.rejects(removePortraitBackground({width:100,height:150},{signal:controller.signal}),{name:'AbortError'});
    assert.equal(mock.workers.length,0);
  } finally {mock.restore();}
});

test('blank predictions fail without erasing the photo',async()=>{
  const mock=browserMock({empty:true});
  try {
    const {removePortraitBackground}=await fresh();
    await assert.rejects(removePortraitBackground({width:100,height:150}),{name:'NoPersonError'});
    assert.ok(mock.workers[0].terminated);
    assert.ok(mock.canvases.every(canvas=>canvas.width===1));
  } finally {mock.restore();}
});

test('failed embedded runtime reports an error and a subsequent request can succeed',async()=>{
  let mock=browserMock({failure:true});
  const {removePortraitBackground}=await fresh();
  try {
    await assert.rejects(removePortraitBackground({width:100,height:150}),/Не удалось обработать волосы/);
    assert.equal(mock.workers[0].terminated,true);
  } finally {mock.restore();}
  mock=browserMock();
  try { assert.equal((await removePortraitBackground({width:100,height:150})).width,100); }
  finally {mock.restore();}
});

test('large embedded binary assets decode exactly across chunk boundaries',()=>{
  const bytes=new Uint8Array(450000);
  for(let index=0;index<bytes.length;index++) bytes[index]=index%251;
  assert.deepEqual(decodeEmbeddedAsset(Buffer.from(bytes).toString('base64')),bytes);
  assert.throws(()=>decodeEmbeddedAsset('bad'));
});
