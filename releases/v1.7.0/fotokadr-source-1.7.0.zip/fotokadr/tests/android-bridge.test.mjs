import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { File } from 'node:buffer';

const source = (await readFile(new URL('../dist/android-bridge.js', import.meta.url), 'utf8')).replace('export const androidBridge', 'globalThis.androidBridge');
function harness() {
  const listeners = new Set(), calls = [];
  const context = vm.createContext({
    Uint8Array, btoa,
    addEventListener(type, listener) { assert.equal(type, 'fotokadr-save-result'); listeners.add(listener); },
    removeEventListener(type, listener) { listeners.delete(listener); },
    FotoKadrAndroid: { saveJpeg(...args) { calls.push(args); } },
  });
  vm.runInContext(source, context);
  return { bridge: context.androidBridge, calls, listeners, context,
    respond(detail) { for (const fn of listeners) fn({ detail }); },
    async started() { for (let i = 0; i < 12 && !calls.length; i++) await new Promise(resolve => setImmediate(resolve)); },
  };
}
test('Android bridge preserves JPEG bytes and waits for the matching native confirmation', async () => {
  const h = harness();
  const bytes = new Uint8Array(100000).map((_, i) => i % 256);
  const pending = h.bridge.save(new File([bytes], 'portrait.jpg', { type: 'image/jpeg' }));
  await h.started();
  assert.equal(h.calls.length, 1);
  const [id, base64, name] = h.calls[0];
  assert.deepEqual(new Uint8Array(Buffer.from(base64, 'base64')), bytes);
  assert.equal(name, 'portrait.jpg');
  h.respond({ id: 'wrong-request', status: 'saved' });
  assert.equal(h.listeners.size, 1);
  h.respond({ id, status: 'saved' });
  await pending;
  assert.equal(h.listeners.size, 0);
});
test('native cancellation and failed writes clean up their callback and support retry', async () => {
  const h = harness();
  for (const status of ['cancelled', 'error', 'saved']) {
    h.calls.length = 0;
    const pending = h.bridge.save(new File(['jpeg'], 'portrait.jpg', { type: 'image/jpeg' }));
    await h.started();
    h.respond({ id: h.calls[0][0], status, message: 'Result' });
    if (status === 'saved') await pending;
    else await assert.rejects(pending, { name: status === 'cancelled' ? 'AbortError' : 'Error' });
    assert.equal(h.listeners.size, 0);
  }
});
test('browser mode has no native bridge and invalid export types never reach Android', async () => {
  const h = harness();
  await assert.rejects(h.bridge.save(new File(['png'], 'image.png', { type: 'image/png' })), /Invalid JPEG/);
  assert.equal(h.calls.length, 0);
  delete h.context.FotoKadrAndroid;
  assert.equal(h.bridge.available(), false);
  await assert.rejects(h.bridge.save(new File([], 'portrait.jpg', { type: 'image/jpeg' })), /not available/);
});
