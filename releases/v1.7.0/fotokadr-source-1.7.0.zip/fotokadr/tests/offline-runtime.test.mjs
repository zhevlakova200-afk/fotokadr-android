import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import test from 'node:test';
import vm from 'node:vm';
import { portraitWorkerMain, normalisePortraitRgb, decodeFaceDetections } from '../dist/background-removal.js';

// Runs the actual browser runtime, WASM binary, model and production worker.
// Synthetic input checks inference/asset loading, not portrait visual quality
// or Android WebView rendering. All HTTP requests are forbidden by this harness.
const runtimeFile = new URL('../dist/vendor/onnxruntime/ort.min.js', import.meta.url);
const moduleFile = new URL('../dist/vendor/onnxruntime/ort-wasm-simd-threaded.mjs', import.meta.url);
const wasmFile = new URL('../dist/vendor/onnxruntime/ort-wasm-simd-threaded.wasm', import.meta.url);
const modelFile = new URL('../dist/models/modnet.onnx', import.meta.url);
const faceFile = new URL('../dist/models/yunet.onnx', import.meta.url);
const assetsAvailable = [runtimeFile, moduleFile, wasmFile, modelFile].every(existsSync);
const origin = 'https://appassets.androidplatform.net';
const config = {
  runtimeUrl: `blob:${origin}/runtime`,
  moduleUrl: `blob:${origin}/module`,
  wasmUrl: `blob:${origin}/wasm`,
};

async function infer(width, height, face = false) {
  const messages = [], fetches = [], imports = [];
  const moduleSource = readFileSync(moduleFile, 'utf8');
  const wasm = readFileSync(wasmFile);
  const context = vm.createContext({
    console, URL, TextDecoder, TextEncoder, performance, setTimeout, clearTimeout,
    location: new URL(`blob:${origin}/worker`), name: '',
    navigator: { hardwareConcurrency: 2 },
    postMessage(data) { messages.push(data); }, close() {},
    async fetch(url) {
      fetches.push(url);
      assert.equal(url, config.wasmUrl, 'only the packaged WASM blob may be fetched');
      return new Response(wasm, { headers: { 'Content-Type': 'application/wasm' } });
    },
    importScripts(url) {
      assert.equal(url, config.runtimeUrl);
      new vm.Script(readFileSync(runtimeFile, 'utf8'), {
        filename: 'packaged-ort.min.js',
        async importModuleDynamically(specifier) {
          imports.push(specifier);
          assert.equal(specifier, config.moduleUrl);
          const module = new vm.SourceTextModule(moduleSource, {
            context, initializeImportMeta(meta) { meta.url = specifier; },
          });
          await module.link(() => { throw new Error('Unexpected external module import'); });
          await module.evaluate();
          return module;
        },
      }).runInContext(context);
    },
  });
  vm.runInContext('self = globalThis;', context);
  vm.runInContext(`(${portraitWorkerMain.toString()})(${JSON.stringify(config)}, ${normalisePortraitRgb.toString()}, ${decodeFaceDetections.toString()});`, context);
  context.modelBytes = readFileSync(face ? faceFile : modelFile);
  context.inputTask = face ? 'face' : 'matte';
  context.inputWidth = width; context.inputHeight = height;
  await vm.runInContext(`
    (() => {
      const rgba = new Uint8ClampedArray(inputWidth * inputHeight * 4);
      for (let y = 0; y < inputHeight; y++) for (let x = 0; x < inputWidth; x++) {
        const offset = (y * inputWidth + x) * 4;
        rgba[offset] = x * 255 / inputWidth;
        rgba[offset + 1] = y * 255 / inputHeight;
        rgba[offset + 2] = 128; rgba[offset + 3] = 255;
      }
      return self.onmessage({ data: {
        width: inputWidth, height: inputHeight, task: inputTask,
        rgba: rgba.buffer, model: new Uint8Array(modelBytes).buffer,
      } });
    })()
  `, context);
  const error = messages.find(message => message.type === 'error');
  assert.equal(error, undefined, error?.message);
  const result = messages.find(message => message.type === 'result');
  assert.ok(result, 'the real model must return a result');
  assert.deepEqual(imports, [config.moduleUrl]);
  assert.deepEqual(fetches, [config.wasmUrl]);
  if(face){assert.equal(result.faces.length,0,'a synthetic gradient has no face');return;}
  assert.deepEqual([result.width, result.height], [width, height]);
  const alpha = new Float32Array(result.alpha);
  assert.equal(alpha.length, width * height);
  let minimum = Infinity, maximum = -Infinity, nonFinite = 0;
  for (const value of alpha) {
    if (!Number.isFinite(value)) nonFinite++;
    minimum = Math.min(minimum, value); maximum = Math.max(maximum, value);
  }
  assert.equal(nonFinite, 0, 'all real model alpha values must be finite');
  assert.ok(minimum >= -1e-6 && maximum <= 1 + 1e-6, `alpha range ${minimum}..${maximum}`);
  assert.deepEqual(imports, [config.moduleUrl]);
  assert.deepEqual(fetches, [config.wasmUrl]);
}

test('real offline YuNet loads locally and does not invent a face on a synthetic gradient', {
  timeout: 180000,
  skip: assetsAvailable && existsSync(faceFile) ? false : 'Run fetch-offline-assets before real-model tests.',
}, async () => { await infer(640,640,true); });

for (const [width, height] of [[512, 768], [768, 512]]) {
  test(`real offline MODNet processes ${width}x${height} using blob module and WASM URLs`, {
    timeout: 180000,
    skip: assetsAvailable ? false : 'Run fetch-offline-assets before real-model tests.',
  }, async () => {
    assert.equal(typeof vm.SourceTextModule, 'function', 'run Node with --experimental-vm-modules');
    await infer(width, height);
  });
}
