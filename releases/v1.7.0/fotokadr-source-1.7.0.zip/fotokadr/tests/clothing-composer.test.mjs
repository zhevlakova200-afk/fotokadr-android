import assert from 'node:assert/strict';
import test from 'node:test';
import {prepareTemplatePixels,clothingReplacementPlacement} from '../dist/clothing-composer.js';

function garment(transparent=false) {
  const width=100,height=120,data=new Uint8ClampedArray(width*height*4);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++) {
    const top=x>=38&&x<=62?70:50+Math.abs(x-50)*.15;
    const inside=y>=top,whiteBadge=x>20&&x<28&&y>88&&y<96;
    data.set(inside&&!whiteBadge?[35,65,45,255]:[255,255,255,inside||!transparent?255:0],(y*width+x)*4);
  }
  return {data,width,height};
}

for(const transparent of [false,true])test(`template prepares ${transparent?'transparent PNG':'white JPG'} without erasing enclosed white insignia`,()=>{
  const {data,width,height}=garment(transparent),copy=data.slice();
  const result=prepareTemplatePixels(data,width,height);
  const alpha=(x,y)=>result.pixels[(y*width+x)*4+3];
  assert.equal(alpha(0,0),0);
  assert.equal(alpha(50,60),0,'neck hole is connected to the outer background');
  assert.equal(alpha(24,92),255,'enclosed white decoration stays opaque');
  assert.equal(alpha(50,100),255);
  assert.ok(result.neck && result.neck.left<.5 && result.neck.right>.5);
  assert.ok(result.neck.y>result.neck.top);
  assert.deepEqual(data,copy,'preparing a template must not mutate its original pixels');
});

test('ordinary rectangular photos do not pretend to have a neck opening',()=>{
  const opaque=new Uint8ClampedArray(100*120*4).fill(100);
  for(let i=3;i<opaque.length;i+=4)opaque[i]=255;
  assert.equal(prepareTemplatePixels(opaque,100,120).neck,null);
  assert.throws(()=>clothingReplacementPlacement({},null,100,120,100,120),/вырез/);
});

test('an already transparent PNG preserves white clothing even at its outer edges',()=>{
  const {data,width,height}=garment(true);
  for(let i=0;i<data.length;i+=4)if(data[i+3])data.set([255,255,255],i);
  const result=prepareTemplatePixels(data,width,height);
  assert.equal(result.pixels[(100*width)*4+3],255,'white sleeve at outer image border stays visible');
  assert.equal(result.pixels[(60*width+50)*4+3],0);
  assert.ok(result.neck);
});

test('automatic fitting aligns the neck centre and preserves garment aspect ratio across photo sizes',()=>{
  const face={x:.35,y:.25,width:.3,height:.3};
  const neck={x:.51,y:.55,width:.24,top:.42,left:.39,right:.63};
  const a=clothingReplacementPlacement(face,neck,800,1200,1000,1400);
  const b=clothingReplacementPlacement(face,neck,1600,2400,2000,2800);
  assert.deepEqual(a.placement,b.placement);
  const size=a.placement.width*800,left=a.placement.x*800-size/2;
  assert.ok(Math.abs(left+neck.x*size-(face.x+face.width/2)*800)<1e-8);
  assert.ok(Math.abs(a.frame.height/a.frame.width-1.4)<1e-8);
});
