import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { File } from 'node:buffer';
import { webcrypto } from 'node:crypto';
import { dimensionsForFormat, cropRect } from '../dist/photo-engine.js';
import { clothingReplacementPlacement } from '../dist/clothing-composer.js';

// Exercise the actual application's registered UI event handlers. Browser ML
// inference is deferred at its public boundary, so cancellation races can be
// reproduced without downloading a model or substituting the application's
// state machine. These checks do not replace real-browser model/visual QA.
const appSource = (await readFile(new URL('../dist/app.js', import.meta.url), 'utf8'))
  .replace(/^import[^\n]*\n/gm, '');
const html = await readFile(new URL('../dist/index.html', import.meta.url), 'utf8');
const clothingSource = (await readFile(new URL('../dist/clothing-library.js', import.meta.url), 'utf8'))
  .replace(/^import[^\n]*\n/gm, '').replace(/^export /gm, '');

function deferred() {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
}

function makeHarness({ touch = false, android = false, cancelSave = false, clothingStore = null } = {}) {
  const elements = new Map();
  const frames = new Map();
  const timers = new Map();
  const requests = [];
  const clothingRequests = [];
  const previews = [];
  const exports = [];
  const crops = [];
  const downloads = [];
  const shares = [];
  const nativeSaves = [];
  let serial = 0;
  let nextDimensions = [2400, 3600];

  class Element {
    constructor(id = '') {
      this.id = id;
      this.hidden = false;
      this.disabled = false;
      this.checked = false;
      this.value = '';
      this.textContent = '';
      this.dataset = {};
      this.style = {};
      this.clientWidth = 320;
      this.clientHeight = 420;
      this.listeners = new Map();
      this.attributes = new Map();
      this.children = [];
      const classes = new Set();
      this.classList = {
        toggle: (name, force) => {
          const present = force === undefined ? !classes.has(name) : force;
          if (present) classes.add(name); else classes.delete(name);
          return present;
        },
        contains: name => classes.has(name),
      };
    }
    addEventListener(type, listener) {
      const listeners = this.listeners.get(type) || [];
      listeners.push(listener);
      this.listeners.set(type, listeners);
    }
    dispatch(type, detail = {}) {
      const event = { type, target: this, preventDefault() {}, ...detail };
      return Promise.all((this.listeners.get(type) || []).map(listener => listener(event)));
    }
    click() {
      if (this.disabled) return Promise.resolve();
      if (this.download) downloads.push(this.download);
      return this.dispatch('click');
    }
    setAttribute(name, value) { this.attributes.set(name, String(value)); }
    getAttribute(name) { return this.attributes.get(name) ?? null; }
    querySelector(selector) {
      if (selector === 'span') return this.childSpan ||= new Element();
      throw new Error(`Unexpected element query: ${selector}`);
    }
    getBoundingClientRect() { return { left: 0, top: 0, right: 300, bottom: 450, width: 300, height: 450 }; }
    setPointerCapture() {}
    focus() { this.focused = true; }
    remove() {}
    append(...children) { this.children.push(...children); }
    replaceChildren(...children) { this.children = children; }
    showModal() {}
    close() {}
  }

  for (const match of html.matchAll(/\bid="([^"]+)"/g)) elements.set(match[1], new Element(match[1]));
  const formats = ['4,6', '9,12', '4,3'].map(format => {
    const element = new Element(); element.dataset.format = format; return element;
  });
  const document = {
    getElementById(id) {
      assert.ok(elements.has(id), `UI element #${id} exists in index.html`);
      return elements.get(id);
    },
    querySelectorAll(selector) { assert.equal(selector, '.format-option'); return formats; },
    createElement() { return new Element(); },
    body: new Element(),
  };
  class FakeImage {
    constructor() {
      [this.naturalWidth, this.naturalHeight] = nextDimensions;
      // Deliberately different layout size: crop gestures must use natural size.
      this.width = 24; this.height = 36;
    }
    set src(value) { this.url = value; queueMicrotask(() => this.onload()); }
  }
  const context = vm.createContext({
    document,
    window: { devicePixelRatio: 1, addEventListener() {} },
    Image: FakeImage,
    AbortController,
    Blob,
    File,
    crypto: webcrypto,
    URL: { createObjectURL: () => `blob:test-${++serial}`, revokeObjectURL() {} },
    navigator: { canShare: () => true, share: async data => { shares.push(data); } },
    matchMedia: query => ({ matches: query === '(pointer: coarse)' && touch }),
    ResizeObserver: class { observe() {} },
    setTimeout(callback, delay) { const id = ++serial; timers.set(id, { callback, delay }); return id; },
    clearTimeout(id) { timers.delete(id); },
    requestAnimationFrame(callback) { const id = ++serial; frames.set(id, callback); return id; },
    dimensionsForFormat,
    clothingReplacementPlacement,
    createClothingLibrary: () => ({ overlay: null, busy: false, replaced: false, adjusting: false, setLocked() {}, photoChanged() {}, clear() {}, cancel() {} }),
    androidBridge: {
      available: () => android,
      async save(file) {
        nativeSaves.push(file);
        if (cancelSave) throw Object.assign(new Error('Cancelled'), { name: 'AbortError' });
      },
    },
    cropRect(...args) { crops.push(args); return cropRect(...args); },
    drawPhoto(canvas, image, options) { previews.push({ image, options: { ...options } }); },
    exportJpeg(image, options) {
      exports.push({ image, options: { ...options } });
      return Promise.resolve(new Blob(['jpeg-test'], { type: 'image/jpeg' }));
    },
    removePortraitBackground(image, options) {
      const task = deferred();
      requests.push({ ...task, image, options });
      return task.promise;
    },
    console: { error() {} },
  });
  if (clothingStore) {
    const factory = vm.runInContext(`(() => { ${clothingSource}\nreturn createClothingLibrary; })()`, context);
    context.createClothingLibrary = options => factory({ ...options, store: clothingStore,
      decode: async () => ({ naturalWidth: 1000, naturalHeight: 800 }),
      makeThumbnail: async () => new Blob(['thumbnail'], { type: 'image/png' }),
      prepareTemplate: async image => ({image,blob:new Blob(['prepared PNG']),neck:{x:.5,y:.45,width:.24,top:.3,left:.38,right:.62}}),
      preparePortrait: (image, options) => {const task=deferred();clothingRequests.push({...task,image,options});return task.promise;},
    });
  }
  vm.runInContext(appSource, context, { filename: 'app.js' });

  function flushFrames() {
    const current = [...frames.values()]; frames.clear(); current.forEach(callback => callback());
  }
  async function settle() {
    for (let round = 0; round < 6; round++) { await Promise.resolve(); flushFrames(); }
  }
  async function upload(name = 'portrait.jpg', dimensions = [2400, 3600]) {
    nextDimensions = dimensions;
    const input = elements.get('file-input');
    input.files = [new File(['image-test'], name, { type: 'image/jpeg' })];
    await input.dispatch('change');
    await settle();
    return previews.at(-1).image;
  }
  async function click(id) { await elements.get(id).click(); await settle(); }
  return { elements, requests, clothingRequests, previews, exports, crops, downloads, shares, nativeSaves, upload, click, settle, formats,
    startWhite: () => elements.get('white-background').click(),
    lastPreview: () => previews.at(-1),
    lastExport: () => exports.at(-1),
    element: id => elements.get(id),
  };
}

test('Android sends the edited JPEG to native saving and never starts a browser download', async () => {
  const h = makeHarness({ touch: true, android: true });
  await h.upload();
  await h.click('bw-mode');
  await h.click('save-photo');
  assert.equal(h.nativeSaves.length, 1);
  assert.equal(h.nativeSaves[0].type, 'image/jpeg');
  assert.match(h.nativeSaves[0].name, /-bw\.jpg$/);
  assert.equal(h.downloads.length, 0);
  assert.equal(h.shares.length, 0);
  assert.equal(h.element('save-photo').disabled, false);
  assert.match(h.element('toast').textContent, /сохранено/);
});

test('cancelling Android saving keeps the editor usable without reporting failure or downloading', async () => {
  const h = makeHarness({ android: true, cancelSave: true });
  await h.upload();
  await h.click('save-photo');
  assert.equal(h.nativeSaves.length, 1);
  assert.equal(h.downloads.length, 0);
  assert.equal(h.element('save-photo').disabled, false);
  assert.doesNotMatch(h.element('toast').textContent, /Не удалось сохранить|Фото сохранено/);
});

test('white background is used by both preview and saved JPG; original restores and invalidates export cache', async () => {
  const h = makeHarness();
  assert.equal(h.element('white-background').disabled, true);
  const original = await h.upload();
  await h.click('save-photo');
  assert.equal(h.lastExport().image, original);
  assert.equal(h.exports.length, 1);

  const pending = h.startWhite();
  assert.equal(h.requests.length, 1);
  assert.equal(h.requests[0].image, original, 'segmentation receives the original colour image');
  assert.equal(h.element('save-photo').disabled, true);
  const white = { width: 2400, height: 3600, kind: 'white-canvas' };
  h.requests[0].resolve(white);
  await pending; await h.settle();
  assert.equal(h.lastPreview().image, white);
  assert.equal(h.element('white-background').getAttribute('aria-pressed'), 'true');
  await h.click('save-photo');
  assert.equal(h.lastExport().image, white);
  assert.equal(h.exports.length, 2);
  assert.match(h.downloads.at(-1), /-white\.jpg$/);

  await h.click('original-background');
  assert.equal(h.lastPreview().image, original);
  await h.click('save-photo');
  assert.equal(h.lastExport().image, original);
  assert.equal(h.exports.length, 3, 'restoring the background does not reuse the white JPG');
  assert.doesNotMatch(h.downloads.at(-1), /-white/);
  await h.click('white-background');
  assert.equal(h.requests.length, 1, 'switching back reuses the completed mask');
  assert.equal(h.lastPreview().image, white);
});

for (const action of ['cancel-background', 'reset', 'original-background']) {
  test(`${action} keeps the original and ignores a late segmentation result`, async () => {
    const h = makeHarness();
    const original = await h.upload();
    const pending = h.startWhite();
    await h.click(action);
    assert.equal(h.requests[0].options.signal.aborted, true);
    assert.equal(h.element('save-photo').disabled, false);
    h.requests[0].options.onProgress('Stale progress');
    assert.notEqual(h.element('background-status').textContent, 'Stale progress');
    const stale = { width: 2400, height: 3600 };
    h.requests[0].resolve(stale);
    await pending; await h.settle();
    assert.equal(h.lastPreview().image, original);
    assert.equal(h.element('white-background').getAttribute('aria-pressed'), 'false');
    await h.click('save-photo');
    assert.equal(h.lastExport().image, original);
    assert.equal(h.element('white-background').disabled, false);
  });
}

test('uploading another portrait discards pending background work from the previous photo', async () => {
  const h = makeHarness();
  const first = await h.upload('first.jpg');
  const pending = h.startWhite();
  const second = await h.upload('second.jpg', [3000, 2000]);
  assert.notEqual(first, second);
  assert.equal(h.requests[0].options.signal.aborted, true);
  h.requests[0].resolve({ width: 2400, height: 3600 });
  await pending; await h.settle();
  assert.equal(h.lastPreview().image, second);
  assert.equal(h.element('image-name').textContent, 'second.jpg');
  assert.equal(h.element('white-background').getAttribute('aria-pressed'), 'false');
  await h.click('save-photo');
  assert.equal(h.lastExport().image, second);
});

test('failed segmentation preserves the photo, explains the error, and permits retry and saving', async () => {
  const h = makeHarness();
  const original = await h.upload();
  const pending = h.startWhite();
  h.requests[0].reject(new Error('Не удалось загрузить модель. Проверьте интернет.'));
  await pending; await h.settle();
  assert.equal(h.lastPreview().image, original);
  assert.match(h.element('background-status').textContent, /Проверьте интернет/);
  assert.equal(h.element('background-status').classList.contains('has-error'), true);
  assert.equal(h.element('white-background').disabled, false);
  assert.equal(h.element('save-photo').disabled, false);
  await h.click('save-photo');
  assert.equal(h.lastExport().image, original);

  const retry = h.startWhite();
  assert.equal(h.requests.length, 2);
  assert.equal(h.element('background-status').classList.contains('has-error'), false);
  const white = { width: 2400, height: 3600 };
  h.requests[1].resolve(white);
  await retry; await h.settle();
  assert.equal(h.lastPreview().image, white);
  assert.equal(h.element('save-photo').disabled, false);
});

test('background replacement retains crop controls and applies grayscale and corner to export', async () => {
  const h = makeHarness();
  const original = await h.upload('portrait.jpg', [2400, 3600]);
  await h.click('bw-mode');
  h.element('corner-toggle').checked = true;
  await h.element('corner-toggle').dispatch('change');
  await h.formats[1].click();
  h.element('zoom').value = '2';
  await h.element('zoom').dispatch('input');
  const pending = h.startWhite();
  assert.equal(h.requests[0].image, original);
  // A memory-limited model may return the same aspect ratio at smaller size.
  const white = { width: 1200, height: 1800 };
  h.requests[0].resolve(white);
  await pending; await h.settle();
  const cropCount = h.crops.length;
  await h.element('canvas-wrap').dispatch('keydown', { key: 'ArrowRight' });
  await h.settle();
  assert.ok(h.crops.slice(cropCount).some(args => args[0] === 2400 && args[1] === 3600), 'gesture geometry uses original natural dimensions');
  assert.ok(h.crops.every(args => args.every(Number.isFinite)), 'canvas results do not produce undefined naturalWidth crop values');
  const preview = h.lastPreview();
  assert.equal(preview.image, white);
  assert.equal(preview.options.widthCm, 9);
  assert.equal(preview.options.heightCm, 12);
  assert.equal(preview.options.zoom, 2);
  assert.notEqual(preview.options.panX, 0);
  await h.click('save-photo');
  const saved = h.lastExport();
  assert.equal(saved.image, white);
  assert.equal(saved.options.grayscale, true);
  assert.equal(saved.options.corner, true);
  assert.equal(saved.options.panX, preview.options.panX);
  assert.equal(saved.options.panY, preview.options.panY);
  assert.match(h.downloads.at(-1), /9x12-white-bw-corner\.jpg$/);
});

test('mouse and touch drags move the same crop and mouse click focuses keyboard controls', async () => {
  const results = [];
  for (const pointerType of ['mouse', 'touch']) {
    const h = makeHarness({ touch: pointerType === 'touch' });
    await h.upload();
    h.element('zoom').value = '2';
    await h.element('zoom').dispatch('input');
    const canvas = h.element('canvas-wrap');
    await canvas.dispatch('pointerdown', { pointerId: 1, pointerType, button: 0, clientX: 150, clientY: 225 });
    await canvas.dispatch('pointermove', { pointerId: 1, clientX: 180, clientY: 205 });
    await canvas.dispatch('pointerup', { pointerId: 1 });
    await h.settle();
    assert.ok(h.lastPreview().options.panX < 0);
    assert.ok(h.lastPreview().options.panY > 0);
    if (pointerType === 'mouse') assert.equal(canvas.focused, true);
    results.push(h.lastPreview().options);
  }
  assert.deepEqual(results[0], results[1]);
});

test('wheel zoom keeps the photo point under the mouse and is included in the saved JPG', async () => {
  const h = makeHarness();
  await h.upload('landscape.jpg', [6000, 4000]);
  const canvas = h.element('canvas-wrap');
  const settings = h.lastPreview().options;
  const before = cropRect(6000, 4000, 4 / 6, settings.zoom, settings.panX, settings.panY);
  let prevented = false;
  await canvas.dispatch('wheel', { deltaY: -100, deltaMode: 0, clientX: 75, clientY: 150, preventDefault() { prevented = true; } });
  await h.settle();
  const preview = h.lastPreview().options;
  const after = cropRect(6000, 4000, 4 / 6, preview.zoom, preview.panX, preview.panY);
  assert.equal(prevented, true);
  assert.ok(preview.zoom > 1);
  assert.ok(Math.abs(before.x + before.width * .25 - after.x - after.width * .25) < 1e-6);
  assert.ok(Math.abs(before.y + before.height / 3 - after.y - after.height / 3) < 1e-6);
  await h.click('save-photo');
  const { previewWidth, ...cropSettings } = preview;
  assert.deepEqual(h.lastExport().options, cropSettings);
});

test('Ctrl/Cmd wheel retains browser zoom and wheel gestures obey photo zoom limits', async () => {
  const h = makeHarness();
  await h.upload();
  const canvas = h.element('canvas-wrap');
  for (const modifier of ['ctrlKey', 'metaKey']) {
    let prevented = false;
    await canvas.dispatch('wheel', { deltaY: -100, [modifier]: true, preventDefault() { prevented = true; } });
    await h.settle();
    assert.equal(prevented, false);
    assert.equal(h.lastPreview().options.zoom, 1);
  }
  h.element('zoom').value = '3';
  await h.element('zoom').dispatch('input');
  await canvas.dispatch('wheel', { deltaY: -120, deltaMode: 1 });
  await h.settle();
  assert.equal(h.lastPreview().options.zoom, 3);
  h.element('zoom').value = '1';
  await h.element('zoom').dispatch('input');
  await canvas.dispatch('wheel', { deltaY: 120, deltaMode: 2 });
  await h.settle();
  assert.equal(h.lastPreview().options.zoom, 1);
});

test('desktop file drop opens a photo and keyboard changes are saved', async () => {
  const h = makeHarness();
  const file = new File(['image-test'], 'dropped-photo.jpg', { type: 'image/jpeg' });
  await h.element('drop-area').dispatch('drop', { dataTransfer: { files: [file] } });
  await h.settle();
  assert.equal(h.element('image-name').textContent, 'dropped-photo.jpg');
  assert.equal(h.element('save-photo').disabled, false);
  const canvas = h.element('canvas-wrap');
  await canvas.dispatch('keydown', { key: '+' });
  await canvas.dispatch('keydown', { key: 'ArrowLeft' });
  await h.settle();
  assert.ok(h.lastPreview().options.zoom > 1);
  assert.ok(h.lastPreview().options.panX > 0);
  await h.click('save-photo');
  const { previewWidth, ...cropSettings } = h.lastPreview().options;
  assert.deepEqual(h.lastExport().options, cropSettings);
  assert.equal(h.downloads.length, 1);
  assert.equal(h.shares.length, 0);
});

test('desktop and phone save the same edited photo with device-appropriate saving', async () => {
  const results = [];
  for (const touch of [false, true]) {
    const h = makeHarness({ touch });
    await h.upload();
    await h.formats[2].click();
    await h.click('bw-mode');
    h.element('corner-toggle').checked = true;
    await h.element('corner-toggle').dispatch('change');
    const processing = h.startWhite();
    const white = { width: 2400, height: 3600 };
    h.requests[0].resolve(white);
    await processing; await h.settle();
    await h.click('save-photo');
    assert.equal(h.lastExport().image, white);
    assert.equal(h.downloads.length, touch ? 0 : 1);
    assert.equal(h.shares.length, touch ? 1 : 0);
    const name = touch ? h.shares[0].files[0].name : h.downloads[0];
    assert.match(name, /4x3-white-bw-corner\.jpg$/);
    results.push(h.lastExport().options);
  }
  assert.deepEqual(results[0], results[1]);
});

function templateStorage() {
  const records = new Map();
  return { records, fail: false,
    async list() { return [...records.values()].map(record => ({ ...record })); },
    async put(record) {
      if (this.fail) throw Object.assign(new Error('Storage is full'), { name: 'QuotaExceededError' });
      records.set(record.id, { ...record });
    },
    async remove(id) { if (this.fail) throw new Error('Удаление не удалось'); records.delete(id); },
  };
}
async function addTemplate(h, name = 'Пиджак.png', contents = 'transparent garment') {
  const input = h.element('clothing-file-input');
  input.files = [new File([contents], name, { type: 'image/png' })];
  await input.dispatch('change'); await h.settle();
}

test('saved clothing reopens in a new editor, survives photo changes/reset and reaches JPEG export', async () => {
  const store = templateStorage();
  const h = makeHarness({ clothingStore: store });
  await h.settle(); await addTemplate(h);
  assert.equal(store.records.size, 1);
  assert.equal(await [...store.records.values()][0].blob.text(), 'transparent garment');
  assert.equal(h.element('clothing-count').textContent, '1');
  const reopened = makeHarness({ clothingStore: store, android: true });
  await reopened.settle();
  assert.equal(reopened.element('clothing-list').children.length, 1);
  await reopened.element('clothing-list').children[0].click();
  await reopened.upload();
  assert.ok(reopened.lastPreview().options.clothing);
  const x = reopened.lastPreview().options.clothing.x;
  await reopened.element('canvas-wrap').dispatch('keydown', { key: 'ArrowRight' });
  await reopened.settle();
  assert.ok(reopened.lastPreview().options.clothing.x > x);
  assert.equal(reopened.lastPreview().options.panX, 0);
  await reopened.click('bw-mode');
  reopened.element('corner-toggle').checked = true;
  await reopened.element('corner-toggle').dispatch('change');
  await reopened.click('save-photo');
  assert.deepEqual(reopened.lastExport().options.clothing, reopened.lastPreview().options.clothing);
  assert.equal(reopened.lastExport().options.grayscale, true);
  assert.equal(reopened.lastExport().options.corner, true);
  assert.match(reopened.nativeSaves[0].name, /-clothing-bw-corner\.jpg$/);
  await reopened.upload('second.jpg');
  assert.equal(store.records.size, 1);
  assert.ok(reopened.lastPreview().options.clothing);
  await reopened.click('reset');
  assert.equal(reopened.lastPreview().options.clothing, null);
  assert.equal(store.records.size, 1);
});

test('clothing names and deletion persist, duplicate imports do not erase a custom name', async () => {
  const store = templateStorage();
  const h = makeHarness({ clothingStore: store });
  await h.settle(); await addTemplate(h);
  h.element('clothing-name').value = 'Синий костюм';
  await h.click('rename-clothing');
  await addTemplate(h, 'Другой файл.png');
  assert.equal(store.records.size, 1);
  assert.equal(h.element('clothing-name').value, 'Синий костюм');
  const reopened = makeHarness({ clothingStore: store });
  await reopened.settle();
  assert.equal(reopened.element('clothing-list').children[0].children[1].textContent, 'Синий костюм');
  await reopened.element('clothing-list').children[0].click();
  store.fail = true;
  await reopened.click('delete-clothing');
  assert.equal(store.records.size, 1);
  assert.equal(reopened.element('clothing-selected').hidden, false);
  store.fail = false;
  await reopened.click('delete-clothing');
  assert.equal(store.records.size, 0);
  assert.equal(reopened.element('clothing-selected').hidden, true);
  const empty = makeHarness({ clothingStore: store }); await empty.settle();
  assert.equal(empty.element('clothing-count').textContent, '0');
});

test('failed clothing import preserves the current overlay and leaves photo saving usable', async () => {
  const store = templateStorage();
  const h = makeHarness({ clothingStore: store });
  await h.settle(); await h.upload(); await addTemplate(h);
  const current = h.lastPreview().options.clothing.image;
  store.fail = true;
  await addTemplate(h, 'Рубашка.png', 'another garment');
  assert.equal(store.records.size, 1);
  assert.equal(h.lastPreview().options.clothing.image, current);
  assert.match(h.element('clothing-status').textContent, /Недостаточно места/);
  assert.equal(h.element('save-photo').disabled, false);
  await h.click('save-photo');
  assert.equal(h.lastExport().options.clothing.image, current);
});

function replacementResult() {
  return {background:{width:1365,height:2048,kind:'reconstructed-background'},preserved:{width:1365,height:2048,kind:'preserved-person'},protected:{width:1365,height:2048,kind:'protected-head-neck'},face:{x:.35,y:.25,width:.3,height:.3}};
}

test('replacement uses the extracted head and cached portrait, exports the composite and restores the original on removal',async()=>{
  const store=templateStorage(),h=makeHarness({clothingStore:store,android:true});
  await h.settle();const original=await h.upload();await addTemplate(h);
  const saved=[...store.records.values()][0];
  assert.ok(saved.preparedBlob && saved.neck,'prepared transparency and neck survive restart');
  const pending=h.element('replace-clothing').click();await h.settle();
  assert.equal(h.element('cancel-clothing').hidden,false);
  assert.equal(h.element('save-photo').disabled,true);
  assert.equal(h.element('white-background').disabled,true);
  const result=replacementResult();h.clothingRequests[0].resolve(result);await pending;await h.settle();
  assert.equal(h.lastPreview().image,result.background);
  assert.equal(h.lastPreview().options.clothing.background,result.background);
  assert.equal(h.lastPreview().options.clothing.protected,result.protected);
  assert.equal(h.element('original-background').disabled,true);
  await h.click('save-photo');
  assert.equal(h.lastExport().image,result.background);
  assert.match(h.nativeSaves[0].name,/-white-clothing\.jpg$/);
  await addTemplate(h,'Форма.png','new uniform');
  assert.equal(h.clothingRequests.length,1,'another template reuses the prepared head');
  assert.equal(h.lastPreview().image,result.background);
  await h.click('remove-clothing');
  assert.equal(h.lastPreview().image,original);
  assert.equal(h.lastPreview().options.clothing,null);
  assert.equal(h.element('original-background').disabled,false);
  assert.equal(store.records.size,2);
});

for(const action of ['cancel','new-photo'])test(`${action} aborts replacement and rejects a late head result`,async()=>{
  const h=makeHarness({clothingStore:templateStorage()});
  await h.settle();let expected=await h.upload();await addTemplate(h);
  const pending=h.element('replace-clothing').click();await h.settle();
  const task=h.clothingRequests[0];
  if(action==='cancel')await h.click('cancel-clothing');else expected=await h.upload('new.jpg');
  assert.equal(task.options.signal.aborted,true);
  task.resolve(replacementResult());await pending;await h.settle();
  assert.equal(h.lastPreview().image,expected);
  assert.equal(h.lastPreview().options.clothing.background,undefined);
  assert.equal(h.element('save-photo').disabled,false);
  assert.equal(h.element('cancel-clothing').hidden,true);
});

test('replacement failure keeps the photo and library and allows retry',async()=>{
  const store=templateStorage(),h=makeHarness({clothingStore:store});
  await h.settle();const original=await h.upload();await addTemplate(h);
  let pending=h.element('replace-clothing').click();await h.settle();
  h.clothingRequests[0].reject(new Error('Не удалось найти лицо.'));await pending;await h.settle();
  assert.equal(h.lastPreview().image,original);
  assert.equal(store.records.size,1);
  assert.match(h.element('clothing-status').textContent,/найти лицо/);
  assert.equal(h.element('replace-clothing').disabled,false);
  pending=h.element('replace-clothing').click();await h.settle();
  const result=replacementResult();h.clothingRequests[1].resolve(result);await pending;await h.settle();
  assert.equal(h.lastPreview().image,result.background);
});

test('layer selector switches repeatedly and clothing drag leaves prepared person masks fixed',async()=>{
  const h=makeHarness({clothingStore:templateStorage()});
  await h.settle();await h.upload();await addTemplate(h);
  const pending=h.element('replace-clothing').click();await h.settle();
  h.clothingRequests[0].resolve(replacementResult());await pending;await h.settle();
  const first=h.lastPreview().options.clothing;
  for(const mode of ['behind','front','behind','front']) {
    h.element('clothing-layer').value=mode;
    await h.element('clothing-layer').dispatch('change');await h.settle();
    assert.equal(h.lastPreview().options.clothing.layerMode,mode);
  }
  const canvas=h.element('canvas-wrap');
  await canvas.dispatch('pointerdown',{pointerId:1,pointerType:'mouse',button:0,clientX:150,clientY:180});
  await canvas.dispatch('pointermove',{pointerId:1,pointerType:'mouse',clientX:180,clientY:210});
  await canvas.dispatch('pointerup',{pointerId:1});await h.settle();
  const after=h.lastPreview().options.clothing;
  assert.notEqual(after.x,first.x);
  assert.equal(after.preserved,first.preserved);
  assert.equal(after.protected,first.protected);
  assert.equal(after.background,first.background);
  await h.click('save-photo');
  assert.equal(h.lastExport().options.clothing.x,after.x);
  assert.equal(h.lastExport().options.clothing.layerMode,'front');
});
