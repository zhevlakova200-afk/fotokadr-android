import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';

const html = await readFile(new URL('../dist/index.html', import.meta.url), 'utf8');
const source = (await readFile(new URL('../dist/theme.js', import.meta.url), 'utf8')).replace('export function applyTheme', 'function applyTheme');
const bootstrap = html.match(/<script>\s*(try \{ document\.documentElement\.dataset\.theme[\s\S]*?)<\/script>/)?.[1];
assert.ok(bootstrap, 'Theme must be restored before the stylesheet loads');

function page(saved) {
  const values = new Map(saved ? [['fotokadr-theme', saved]] : []);
  const calls = [];
  const attributes = new Map();
  const button = {
    title: '',
    setAttribute(name, value) { attributes.set(name, value); },
    querySelector() { return { setAttribute(name, value) { attributes.set(name, value); } }; },
    addEventListener(name, listener) { assert.equal(name, 'click'); this.click = listener; },
  };
  const meta = { setAttribute(name, value) { attributes.set('meta:' + name, value); } };
  const document = {
    documentElement: { dataset: {} },
    getElementById(id) { assert.equal(id, 'theme-toggle'); return button; },
    querySelector() { return meta; },
  };
  const localStorage = { getItem(key) { return values.get(key) ?? null; }, setItem(key, value) { values.set(key, value); } };
  const window = { FotoKadrTheme: { setTheme(mode) { calls.push(mode); } } };
  const context = vm.createContext({ document, localStorage, window });
  vm.runInContext(bootstrap, context);
  vm.runInContext(source, context);
  return { button, attributes, values, calls, document };
}

test('one tap switches the header icon and accessible label, persists both directions', () => {
  const p = page();
  assert.equal(p.document.documentElement.dataset.theme, 'light');
  assert.equal(p.attributes.get('href'), '#i-sun');
  assert.equal(p.attributes.get('aria-label'), 'Включить тёмную тему');
  p.button.click();
  assert.equal(p.document.documentElement.dataset.theme, 'dark');
  assert.equal(p.attributes.get('href'), '#i-moon');
  assert.equal(p.attributes.get('aria-label'), 'Включить светлую тему');
  assert.equal(p.attributes.get('meta:content'), '#121212');
  assert.equal(p.values.get('fotokadr-theme'), 'dark');
  assert.deepEqual(p.calls, ['dark']);
  p.button.click();
  assert.equal(p.document.documentElement.dataset.theme, 'light');
  assert.equal(p.attributes.get('href'), '#i-sun');
  assert.equal(p.values.get('fotokadr-theme'), 'light');
  assert.deepEqual(p.calls, ['dark', 'light']);
});

test('saved dark mode applies before paint and is restored after reopening', () => {
  const p = page('dark');
  assert.equal(p.document.documentElement.dataset.theme, 'dark');
  assert.equal(p.attributes.get('href'), '#i-moon');
  assert.equal(p.attributes.get('aria-label'), 'Включить светлую тему');
  assert.equal(p.calls.length, 0);
});
