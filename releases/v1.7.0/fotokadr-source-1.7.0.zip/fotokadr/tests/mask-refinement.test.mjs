import assert from 'node:assert/strict';
import test from 'node:test';
import { buildMattingReferences, renderMatteOnWhite } from '../dist/background-removal.js';

function referenceMap(width,colour) {
  const map=new Uint8ClampedArray(width*4);
  if(colour) for(let x=0;x<width;x++) map.set([...colour,255],x*4);
  return map;
}

function composite({alpha,foreground,background,colours,width=alpha.length}) {
  const pixels=new Uint8ClampedArray(colours.flatMap(colour=>[...colour,255]));
  renderMatteOnWhite(pixels,width,1,0,1,{alpha:new Float32Array(alpha),width:alpha.length,height:1},{foreground:referenceMap(alpha.length,foreground),background:referenceMap(alpha.length,background)});
  return Array.from({length:width},(_,x)=>Array.from(pixels.slice(x*4,x*4+3)));
}

const observed=(foreground,background,alpha)=>foreground.map((value,channel)=>Math.round(alpha*value+(1-alpha)*background[channel]));

test('fractional hair keeps its real coverage instead of being attenuated twice',()=>{
  const fg=[30,20,10],bg=[100,140,180];
  const alpha=[.15,.4,.8];
  const result=composite({alpha,foreground:fg,background:bg,colours:alpha.map(a=>observed(fg,bg,a))});
  for(let i=0;i<alpha.length;i++) for(let c=0;c<3;c++) {
    const correct=alpha[i]*fg[c]+(1-alpha[i])*255;
    assert.ok(Math.abs(result[i][c]-correct)<=2,'removes the old background contribution before adding white');
  }
});

test('original-resolution strands are recovered inside a coarse uncertain hair region',()=>{
  const fg=[20,30,40],bg=[220,210,200];
  const actual=[.1,.9,.2,.8];
  const result=composite({alpha:[.5,.5,.5,.5],foreground:fg,background:bg,colours:actual.map(a=>observed(fg,bg,a))});
  const dark=result[1][0],light=result[0][0];
  assert.ok(light-dark>120,'retains fine colour structure instead of blurring all strands to the same matte');
  assert.ok(result[3][0]<result[2][0]);
});

test('model transparency is preserved for low-contrast blonde hair with no reliable colour separation',()=>{
  const fg=[225,220,210],bg=[230,225,215];
  const alpha=[.08,.3,.6];
  const result=composite({alpha,foreground:fg,background:bg,colours:alpha.map(a=>observed(fg,bg,a))});
  for(let i=0;i<alpha.length;i++) {
    assert.ok(result[i][0]<255,'does not threshold pale wisps out of the matte');
    assert.ok(Math.abs(result[i][0]-(alpha[i]*fg[0]+(1-alpha[i])*255))<=2);
  }
});

test('opaque hair texture stays untouched and transparent background becomes pure white',()=>{
  const result=composite({alpha:[0,1,1,0],foreground:[20,30,40],background:[100,140,180],colours:[[90,130,170],[12,34,56],[43,51,63],[10,80,200]]});
  assert.deepEqual(result,[[255,255,255],[12,34,56],[43,51,63],[255,255,255]]);
});

test('local foreground/background references use confident pixels without modifying the original',()=>{
  const colours=[[200,210,220],[190,200,210],[100,110,120],[30,40,50],[20,30,40]];
  const pixels=new Uint8ClampedArray(colours.flatMap(colour=>[...colour,255]));
  const copy=new Uint8ClampedArray(pixels);
  const alpha=new Float32Array([0,0,.5,1,1]);
  const refs=buildMattingReferences(pixels,alpha,5,1);
  assert.deepEqual(Array.from(refs.background.slice(8,12)),[190,200,210,255]);
  assert.deepEqual(Array.from(refs.foreground.slice(8,12)),[30,40,50,255]);
  assert.deepEqual(pixels,copy);
});

test('banded rendering matches whole-image rendering without seams',()=>{
  const width=4,height=4;
  const alpha=new Float32Array([0,.2,.7,1]);
  const matte={alpha,width:2,height:2};
  const refs={foreground:referenceMap(4,[30,50,70]),background:referenceMap(4,[150,170,190])};
  const whole=new Uint8ClampedArray(width*height*4).fill(100);
  const banded=new Uint8ClampedArray(whole);
  renderMatteOnWhite(whole,width,height,0,height,matte,refs);
  for(let row=0;row<height;row++) {
    const band=banded.subarray(row*width*4,(row+1)*width*4);
    renderMatteOnWhite(band,width,height,row,1,matte,refs);
  }
  assert.deepEqual(banded,whole);
});
