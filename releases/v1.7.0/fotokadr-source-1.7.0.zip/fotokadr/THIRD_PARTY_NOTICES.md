# Third-party software and model notices

## MODNet

MODNet: Real-Time Trimap-Free Portrait Matting via Objective Decomposition.
Authors: Zhanghan Ke, Jiayu Sun, Kaican Li, Qiong Yan, Rynson W.H. Lau.
Original repository and license: https://github.com/ZHKKKe/MODNet
License: Apache License, Version 2.0 — https://www.apache.org/licenses/LICENSE-2.0

ONNX export by Xenova: https://huggingface.co/Xenova/modnet
Pinned revision: 7e0f55f28727b43369531f75e0539ecc4912af82
File: onnx/model.onnx (full precision).
Upstream preprocessing: https://huggingface.co/Xenova/modnet/blob/7e0f55f28727b43369531f75e0539ecc4912af82/preprocessor_config.json

The offline 1.4 build bundles the unmodified model in the Android APK and in the
standalone HTML. The build script verifies SHA-256:
07c308cf0fc7e6e8b2065a12ed7fc07e1de8febb7dc7839d7b7f15dd66584df9.
The source preparation command fetches it once at build time. A source-only
checkout may not yet contain the model; such a checkout cannot produce an
offline release until all assets and license texts have been fetched.
The complete MODNet license is included as dist/models/MODNET-LICENSE and
embedded in standalone releases.

## ONNX Runtime Web 1.20.1

Copyright (c) Microsoft Corporation. All rights reserved.
Repository: https://github.com/microsoft/onnxruntime
License: MIT — https://github.com/microsoft/onnxruntime/blob/v1.20.1/LICENSE
Runtime URL: https://cdn.jsdelivr.net/npm/onnxruntime-web@1.20.1/dist/

The runtime JS, ES module, and WASM are bundled at build time. Processing uses
only these local resources; no user photo is uploaded to a distribution service.
The complete runtime license is included as dist/vendor/onnxruntime/LICENSE
and embedded in standalone releases.

## YuNet face detector

Copyright (c) 2020 Shiqi Yu. MIT license, included in dist/models/YUNET-LICENSE.
Source: https://github.com/opencv/opencv_zoo/tree/48b10fa505aeb51fbd127fc60a5c660040e823b7/models/face_detection_yunet
File: face_detection_yunet_2023mar.onnx (232589 bytes), distributed as models/yunet.onnx.
SHA-256: 8f2383e4dd3cfbb4553ea8718107fc0423210dc964f9f4280604804ed2552fa4.
This unmodified model finds face position and landmarks for clothing placement;
it does not identify the person. It is bundled in offline releases.

## Android SDK build tools

The optional Android build uses Google's Android SDK platform 35 and build tools
35.0.0. SDK archives are fetched from Google's official repository and verified
against its published archive checksums. SDK tools, signing keys and passwords
are excluded from the distributable source archive and from the app.
