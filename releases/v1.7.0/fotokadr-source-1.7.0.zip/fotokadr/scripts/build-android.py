"""Build and sign the offline Android APK with official SDK command-line tools.

No network access is used by this command. Run the two setup scripts first.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import secrets
import shutil
import subprocess
import zipfile
import xml.etree.ElementTree as ET
from offline_assets import validate, ASSETS, LICENSES

ROOT = Path(__file__).resolve().parent.parent

def run(*args, **kwargs):
    subprocess.run([str(arg) for arg in args], check=True, **kwargs)

def java_compiler():
    if shutil.which('javac'):
        return ['javac']
    # Some managed images include the JDK module but omit the javac launcher.
    command = ['java', '-m', 'jdk.compiler/com.sun.tools.javac.Main']
    result = subprocess.run([*command, '-version'], capture_output=True, text=True)
    if result.returncode:
        raise SystemExit('Java compiler is missing. Install JDK 17 or 21.')
    return command

def signing_key(directory):
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    settings = directory / 'signing.json'
    keystore = directory / 'fotokadr.p12'
    if settings.exists():
        password = json.loads(settings.read_text())['password']
        if not keystore.exists(): raise SystemExit('Signing key is missing. Restore it to keep app updates compatible.')
    else:
        if keystore.exists(): raise SystemExit('Signing configuration is missing. Restore it instead of replacing the key.')
        password = secrets.token_urlsafe(32)
        env = dict(os.environ, FOTOKADR_SIGNING_PASSWORD=password)
        run('keytool', '-genkeypair', '-keystore', keystore, '-storetype', 'PKCS12', '-alias', 'fotokadr',
            '-storepass:env', 'FOTOKADR_SIGNING_PASSWORD', '-keypass:env', 'FOTOKADR_SIGNING_PASSWORD',
            '-keyalg', 'RSA', '-keysize', '3072', '-validity', '10000', '-dname', 'CN=FotoKadr', env=env)
        keystore.chmod(0o600)
        with os.fdopen(os.open(settings, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), 'w') as output:
            json.dump({'password': password}, output)
    return keystore, dict(os.environ, FOTOKADR_SIGNING_PASSWORD=password)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sdk', type=Path, default=Path(os.environ.get('ANDROID_HOME', ROOT / 'build/android-sdk')))
    parser.add_argument('--signing-dir', type=Path, default=ROOT.parent.parent / '.fotokadr-signing')
    parser.add_argument('--output', type=Path, default=ROOT.parent.parent)
    args = parser.parse_args()
    validate(ROOT / 'dist')
    platform = args.sdk / 'platforms/android-35/android.jar'
    tools = args.sdk / 'build-tools/35.0.0'
    required = [platform, *(tools / item for item in ['aapt2', 'd8', 'zipalign', 'apksigner'])]
    if any(not item.is_file() for item in required):
        raise SystemExit('Android SDK is incomplete. Run python scripts/setup-android-sdk.py first.')
    for command in ['java', 'keytool']:
        if not shutil.which(command): raise SystemExit('JDK is required: missing ' + command)
    compiler = java_compiler()
    version = json.loads((ROOT / 'package.json').read_text())['version']
    major, minor, patch = map(int, version.split('.'))
    version_code = major * 10000 + minor * 100 + patch
    stage = ROOT / 'build/android'
    if stage.exists(): shutil.rmtree(stage)
    for folder in ['assets/web', 'generated', 'classes', 'dex']:
        (stage / folder).mkdir(parents=True, exist_ok=True)
    shutil.copytree(ROOT / 'dist', stage / 'assets/web', dirs_exist_ok=True)
    shutil.copyfile(ROOT / 'THIRD_PARTY_NOTICES.md', stage / 'assets/web/THIRD_PARTY_NOTICES.txt')
    source = ROOT / 'android/app/src/main'
    # AGP uses namespace/applicationId from build.gradle. Direct aapt2 builds
    # require the package attribute in a generated copy of the same manifest.
    ET.register_namespace('android', 'http://schemas.android.com/apk/res/android')
    manifest = ET.parse(source / 'AndroidManifest.xml')
    manifest.getroot().set('package', 'ru.fotokadr.app')
    manifest.write(stage / 'AndroidManifest.xml', encoding='utf-8', xml_declaration=True)
    run(tools / 'aapt2', 'compile', '--dir', source / 'res', '-o', stage / 'resources.zip')
    run(tools / 'aapt2', 'link', '-o', stage / 'unsigned.apk', '--manifest', stage / 'AndroidManifest.xml',
        '--java', stage / 'generated', '-I', platform, '-A', stage / 'assets', '--min-sdk-version', '26',
        '--target-sdk-version', '35', '--version-code', str(version_code), '--version-name', version, stage / 'resources.zip')
    java_sources = sorted((source / 'java').rglob('*.java')) + sorted((stage / 'generated').rglob('*.java'))
    # Use the JDK's complete Java 8 API for lambda bootstrap methods, and the
    # Android SDK on the classpath for android.* APIs. android.jar alone is not
    # a complete Java bootstrap classpath (LambdaMetafactory is missing).
    run(*compiler, '-encoding', 'UTF-8', '--release', '8', '-classpath', platform,
        '-d', stage / 'classes', *java_sources)
    run(tools / 'd8', '--min-api', '26', '--lib', platform, '--output', stage / 'dex', *sorted((stage / 'classes').rglob('*.class')))
    with zipfile.ZipFile(stage / 'unsigned.apk', 'a', zipfile.ZIP_DEFLATED) as apk:
        for dex in sorted((stage / 'dex').glob('*.dex')): apk.write(dex, dex.name)
    run(tools / 'zipalign', '-f', '4', stage / 'unsigned.apk', stage / 'aligned.apk')
    keystore, env = signing_key(args.signing_dir)
    args.output.mkdir(parents=True, exist_ok=True)
    final = args.output / f'fotokadr-android-{version}.apk'
    run(tools / 'apksigner', 'sign', '--ks', keystore, '--ks-key-alias', 'fotokadr',
        '--ks-pass', 'env:FOTOKADR_SIGNING_PASSWORD', '--key-pass', 'env:FOTOKADR_SIGNING_PASSWORD',
        '--out', stage / 'signed.apk', stage / 'aligned.apk', env=env)
    run(tools / 'apksigner', 'verify', '--verbose', stage / 'signed.apk')
    run(tools / 'zipalign', '-c', '4', stage / 'signed.apk')
    permissions = subprocess.check_output([str(tools / 'aapt2'), 'dump', 'permissions', str(stage / 'signed.apk')], text=True)
    if 'android.permission.INTERNET' in permissions:
        raise SystemExit('Offline APK unexpectedly requests Internet permission.')
    with zipfile.ZipFile(stage / 'signed.apk') as apk:
        for name in [*ASSETS.values(), *LICENSES]:
            if apk.read('assets/web/' + name) != (ROOT / 'dist' / name).read_bytes():
                raise SystemExit('APK contains an incorrect offline asset: ' + name)
    shutil.copyfile(stage / 'signed.apk', final)
    digest = hashlib.sha256(final.read_bytes()).hexdigest()
    final.with_suffix('.apk.sha256').write_text(digest + '  ' + final.name + '\n')
    print('Signed offline APK: ' + str(final))
    print(f'Size: {final.stat().st_size / 1000000:.1f} MB')
    print('The signing key stays outside the source archive. Keep it for future updates.')

if __name__ == '__main__':
    main()
