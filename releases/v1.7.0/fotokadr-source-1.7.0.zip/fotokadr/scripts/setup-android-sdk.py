"""Install only Android API 35 and build tools 35.0.0 from Google's SDK registry.

No Gradle, emulator, system changes, or administrator access is needed.
The inherited HTTPS proxy and TLS verification remain enabled.
"""
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.parse import urljoin
import argparse
import hashlib
import os
import shutil
import tempfile
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
BASE = 'https://dl.google.com/android/repository/'
PACKAGES = [('platforms;android-35', 'android.jar'), ('build-tools;35.0.0', 'aapt2')]

def request(url):
    return urlopen(Request(url, headers={'User-Agent': 'FotoKadr-Android-build/1.4'}), timeout=45)

def child(element, name):
    return next((item for item in element if item.tag.rsplit('}', 1)[-1] == name), None)

def text(element, name, default=''):
    item = child(element, name)
    return item.text.strip() if item is not None and item.text else default

def descriptor(registry, package):
    node = next((node for node in registry.iter() if node.tag.rsplit('}', 1)[-1] == 'remotePackage' and node.get('path') == package), None)
    if node is None:
        raise SystemExit('Android SDK package not listed: ' + package)
    for archive in child(node, 'archives'):
        if text(archive, 'host-os') not in ('', 'linux'):
            continue
        complete = child(archive, 'complete')
        checksum = child(complete, 'checksum')
        return urljoin(BASE, text(complete, 'url')), int(text(complete, 'size')), checksum.get('type', 'sha1'), checksum.text.strip()
    raise SystemExit('No Linux archive for ' + package)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sdk', type=Path, default=Path(os.environ.get('ANDROID_HOME', ROOT / 'build/android-sdk')))
    args = parser.parse_args()
    args.sdk.mkdir(parents=True, exist_ok=True)
    needed = [(name, marker) for name, marker in PACKAGES if not (args.sdk / name.replace(';', '/') / marker).exists()]
    if not needed:
        print('Android SDK is already available: ' + str(args.sdk)); return
    with request(BASE + 'repository2-1.xml') as response:
        registry = ET.fromstring(response.read())
    for name, marker in needed:
        url, size, algorithm, checksum = descriptor(registry, name)
        if not url.startswith(BASE):
            raise SystemExit('Unexpected Android SDK download host')
        print(f'Downloading {name} ({size // 1000000} MB)', flush=True)
        with tempfile.TemporaryDirectory(prefix='sdk-download-', dir=args.sdk) as temp:
            temp = Path(temp)
            digest = hashlib.new(algorithm)
            archive = temp / 'package.zip'
            received = 0
            with request(url) as response, archive.open('wb') as output:
                while chunk := response.read(1024 * 1024):
                    output.write(chunk); digest.update(chunk); received += len(chunk)
            if received != size or digest.hexdigest().lower() != checksum.lower():
                raise SystemExit('Android SDK archive verification failed: ' + name)
            extracted = temp / 'extracted'
            extracted.mkdir()
            with zipfile.ZipFile(archive) as zipped:
                for member in zipped.infolist():
                    destination = (extracted / member.filename).resolve()
                    if not destination.is_relative_to(extracted.resolve()):
                        raise SystemExit('Unsafe SDK archive path')
                zipped.extractall(extracted)
            matches = list(extracted.rglob(marker))
            if len(matches) != 1:
                raise SystemExit('Unexpected SDK package layout: ' + name)
            destination = args.sdk / name.replace(';', '/')
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(matches[0].parent, destination, dirs_exist_ok=True)
            for executable in ('aapt', 'aapt2', 'd8', 'apksigner', 'zipalign'):
                path = destination / executable
                if path.exists(): path.chmod(0o755)
        print('Installed ' + name, flush=True)
    print('Android SDK ready: ' + str(args.sdk))

if __name__ == '__main__':
    main()
