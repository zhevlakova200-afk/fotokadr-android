"""Create a source handoff, excluding SDK, build outputs and signing secrets."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

root = Path(__file__).resolve().parent.parent
output = root.parent.parent / 'fotokadr-android-project.zip'
included = ['android', 'dist', 'scripts', 'tests', '.github', 'НАЧНИТЕ_ЗДЕСЬ.md', 'README.md', 'THIRD_PARTY_NOTICES.md', 'package.json', '.gitignore']
excluded = {'__pycache__', 'node_modules', 'build', '.git', '.gradle', '.idea'}
with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name in included:
        item = root / name
        paths = item.rglob('*') if item.is_dir() else [item]
        for path in sorted(paths):
            if path.is_file() and path.name != 'local.properties' and not excluded.intersection(path.relative_to(root).parts) and path.suffix not in {'.part', '.p12', '.keystore', '.jks', '.iml'}:
                archive.write(path, 'fotokadr/' + str(path.relative_to(root)))
version = json.loads((root / 'package.json').read_text())['version']
versioned = output.with_name('fotokadr-android-project-' + version + '.zip')
shutil.copyfile(output, versioned)
versioned.with_suffix('.zip.sha256').write_text(hashlib.sha256(versioned.read_bytes()).hexdigest() + '  ' + versioned.name + '\n')
print('Android source project: ' + str(output))
print('Versioned source project: ' + str(versioned))
