"""Shared validation: an offline release must contain the real model and engine."""
from pathlib import Path
import hashlib

ASSETS = {
    'runtime': 'vendor/onnxruntime/ort.min.js',
    'module': 'vendor/onnxruntime/ort-wasm-simd-threaded.mjs',
    'wasm': 'vendor/onnxruntime/ort-wasm-simd-threaded.wasm',
    'model': 'models/modnet.onnx',
    'face': 'models/yunet.onnx',
}
LICENSES = ['models/MODNET-LICENSE', 'models/YUNET-LICENSE', 'vendor/onnxruntime/LICENSE']
FACE_SHA256 = '8f2383e4dd3cfbb4553ea8718107fc0423210dc964f9f4280604804ed2552fa4'
MODEL_SHA256 = '07c308cf0fc7e6e8b2065a12ed7fc07e1de8febb7dc7839d7b7f15dd66584df9'

def validate(dist: Path):
    missing = [name for name in [*ASSETS.values(), *LICENSES] if not (dist / name).is_file()]
    if missing:
        raise SystemExit('Offline assets are missing: ' + ', '.join(missing) + '. Run python scripts/fetch-offline-assets.py. No offline release was created.')
    if hashlib.sha256((dist / ASSETS['model']).read_bytes()).hexdigest() != MODEL_SHA256:
        raise SystemExit('MODNet checksum mismatch. No offline release was created.')
    if hashlib.sha256((dist / ASSETS['face']).read_bytes()).hexdigest() != FACE_SHA256:
        raise SystemExit('YuNet checksum mismatch. No offline release was created.')
    with (dist / ASSETS['wasm']).open('rb') as wasm:
        if wasm.read(8) != b'\x00asm\x01\x00\x00\x00':
            raise SystemExit('Invalid WebAssembly binary. No offline release was created.')
    for key, minimum in [('runtime', 10000), ('module', 1000), ('wasm', 1000000)]:
        if (dist / ASSETS[key]).stat().st_size < minimum:
            raise SystemExit('Truncated asset: ' + ASSETS[key])
    for name in LICENSES:
        if (dist / name).stat().st_size < 200:
            raise SystemExit('Missing license text: ' + name)
