"""Produce a single HTML app and a source ZIP without remote build dependencies."""
from pathlib import Path
import base64
import hashlib
import json
import re
import shutil
import zipfile
from offline_assets import validate, ASSETS, LICENSES

root = Path(__file__).resolve().parent.parent
dist = root / 'dist'
output = root.parent.parent
asset_paths = ASSETS
validate(dist)
html = (dist / 'index.html').read_text()
html = html.replace('<link rel="stylesheet" href="./style.css">', '<style>' + (dist / 'style.css').read_text() + '</style>')
html = html.replace('<link rel="manifest" href="./manifest.webmanifest">', '')
for name, mime in [('icon.svg', 'image/svg+xml'), ('icon-192.png', 'image/png')]:
    data = base64.b64encode((dist / name).read_bytes()).decode()
    html = html.replace(f'href="./{name}"', f'href="data:{mime};base64,{data}"')

def module_scope(filename, exports):
    source = (dist / filename).read_text()
    source = re.sub(r'^import[^\n]+\n', '', source, flags=re.M)
    source = re.sub(r'^export (?=(?:async )?function |const |let |class )', '', source, flags=re.M)
    return 'const { ' + ', '.join(exports) + ' } = (() => {\n' + source + '\nreturn { ' + ', '.join(exports) + ' };\n})();\n'

script = module_scope('photo-engine.js', ['dimensionsForFormat', 'cropRect', 'drawPhoto', 'exportJpeg'])
script += module_scope('background-removal.js', ['removePortraitBackground', 'detectPortraitFace'])
script += module_scope('android-bridge.js', ['androidBridge'])
script += module_scope('template-store.js', ['createTemplateStore'])
script += module_scope('clothing-composer.js', ['prepareClothingTemplate', 'prepareReplacementPortrait', 'clothingReplacementPlacement'])
script += module_scope('clothing-library.js', ['createClothingLibrary'])
script += re.sub(r'^import[^\n]+\n', '', (dist / 'app.js').read_text(), flags=re.M)
html = html.replace('<script type="module" src="./app.js"></script>', '<script type="module">' + script + '</script>')
embedded = '\n'.join('<script type="application/octet-stream" id="offline-' + name + '">' + base64.b64encode((dist / path).read_bytes()).decode() + '</script>' for name, path in asset_paths.items())
notices = [{'name': 'Third-party notices', 'text': (root / 'THIRD_PARTY_NOTICES.md').read_text()}]
notices += [{'name': name, 'text': (dist / name).read_text()} for name in LICENSES]
embedded += '\n<script type="application/json" id="third-party-notices">' + json.dumps(notices, ensure_ascii=False).replace('<', '\\u003c') + '</script>'
html = html.replace('<script type="module">', embedded + '\n<script type="module">', 1)
(output / 'fotokadr.html').write_text(html)
with zipfile.ZipFile(output / 'fotokadr.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    archive.write(output / 'fotokadr.html', 'fotokadr.html')
    for path in sorted(root.rglob('*')):
        if path.is_file() and path.name != 'local.properties' and not {'.git', '.openai', '.gradle', '.idea', 'node_modules', '__pycache__', 'build'}.intersection(path.relative_to(root).parts) and path.suffix not in {'.p12', '.jks', '.keystore', '.part', '.iml'}:
            archive.write(path, 'source/' + str(path.relative_to(root)))
version = json.loads((root / 'package.json').read_text())['version']
for extension in ('html', 'zip'):
    shutil.copyfile(output / f'fotokadr.{extension}', output / f'fotokadr-{version}.{extension}')
shutil.copyfile(output / 'fotokadr.html', output / f'fotokadr-{version}-offline.html')
print(f'Updated fotokadr-{version}.html and fotokadr-{version}.zip in {output}')
