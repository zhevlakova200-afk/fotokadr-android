"""Vendor the pinned model/runtime; never downloads user photos or credentials."""
from pathlib import Path
from urllib.request import urlopen, Request
import concurrent.futures, hashlib, json, os

root=Path(__file__).resolve().parent.parent
assets=[
 ('vendor/onnxruntime/ort.min.js','https://cdn.jsdelivr.net/npm/onnxruntime-web@1.20.1/dist/ort.min.js',None),
 ('vendor/onnxruntime/ort-wasm-simd-threaded.mjs','https://cdn.jsdelivr.net/npm/onnxruntime-web@1.20.1/dist/ort-wasm-simd-threaded.mjs',None),
 ('vendor/onnxruntime/ort-wasm-simd-threaded.wasm','https://cdn.jsdelivr.net/npm/onnxruntime-web@1.20.1/dist/ort-wasm-simd-threaded.wasm',None),
 ('models/modnet.onnx','https://huggingface.co/Xenova/modnet/resolve/7e0f55f28727b43369531f75e0539ecc4912af82/onnx/model.onnx','07c308cf0fc7e6e8b2065a12ed7fc07e1de8febb7dc7839d7b7f15dd66584df9'),
 ('vendor/onnxruntime/LICENSE','https://raw.githubusercontent.com/microsoft/onnxruntime/v1.20.1/LICENSE',None),
 ('models/MODNET-LICENSE','https://raw.githubusercontent.com/ZHKKKe/MODNet/master/LICENSE',None),
 ('models/yunet.onnx','https://media.githubusercontent.com/media/opencv/opencv_zoo/48b10fa505aeb51fbd127fc60a5c660040e823b7/models/face_detection_yunet/face_detection_yunet_2023mar.onnx','8f2383e4dd3cfbb4553ea8718107fc0423210dc964f9f4280604804ed2552fa4'),
 ('models/YUNET-LICENSE','https://raw.githubusercontent.com/opencv/opencv_zoo/48b10fa505aeb51fbd127fc60a5c660040e823b7/models/face_detection_yunet/LICENSE',None),
]

def download(asset):
 name,url,expected=asset
 path=root/'dist'/name
 path.parent.mkdir(parents=True,exist_ok=True)
 if path.exists() and (not expected or hashlib.sha256(path.read_bytes()).hexdigest()==expected):
  return {'path':name,'size':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 part=path.with_name(path.name+'.part')
 try:
  print(f'Downloading {name}',flush=True)
  with urlopen(Request(url,headers={'User-Agent':'FotoKadr-offline-build/1.4'}),timeout=45) as response, part.open('wb') as output:
   while chunk:=response.read(1024*1024): output.write(chunk)
  digest=hashlib.sha256(part.read_bytes()).hexdigest()
  if expected and digest!=expected: raise RuntimeError(f'{name}: model SHA-256 mismatch')
  if name.endswith(('.wasm','.onnx')) and part.stat().st_size < (200000 if name == 'models/yunet.onnx' else 1000000): raise RuntimeError(f'{name}: truncated asset')
  os.replace(part,path)
  print(f'Ready: {name} ({path.stat().st_size} bytes)',flush=True)
  return {'path':name,'size':path.stat().st_size,'sha256':digest}
 finally:
  part.unlink(missing_ok=True)

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 results=list(pool.map(download,assets))
version=json.loads((root/'package.json').read_text())['version']
(root/'dist'/'offline-assets.json').write_text(json.dumps({'version':version,'assets':results},indent=2)+'\n')
for asset in results: print(f'{asset["path"]}: {asset["size"]} bytes')
